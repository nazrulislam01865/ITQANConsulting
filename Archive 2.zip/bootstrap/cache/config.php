<?php return array (
  'hashing' => 
  array (
    'driver' => 'bcrypt',
    'bcrypt' => 
    array (
      'rounds' => '12',
      'verify' => true,
      'limit' => NULL,
    ),
    'argon' => 
    array (
      'memory' => 65536,
      'threads' => 1,
      'time' => 4,
      'verify' => true,
    ),
    'rehash_on_login' => true,
  ),
  'concurrency' => 
  array (
    'default' => 'process',
  ),
  'broadcasting' => 
  array (
    'default' => 'log',
    'connections' => 
    array (
      'reverb' => 
      array (
        'driver' => 'reverb',
        'key' => NULL,
        'secret' => NULL,
        'app_id' => NULL,
        'options' => 
        array (
          'host' => NULL,
          'port' => 443,
          'scheme' => 'https',
          'useTLS' => true,
        ),
        'client_options' => 
        array (
        ),
      ),
      'pusher' => 
      array (
        'driver' => 'pusher',
        'key' => NULL,
        'secret' => NULL,
        'app_id' => NULL,
        'options' => 
        array (
          'cluster' => NULL,
          'host' => 'api-mt1.pusher.com',
          'port' => 443,
          'scheme' => 'https',
          'encrypted' => true,
          'useTLS' => true,
        ),
        'client_options' => 
        array (
        ),
      ),
      'ably' => 
      array (
        'driver' => 'ably',
        'key' => NULL,
      ),
      'log' => 
      array (
        'driver' => 'log',
      ),
      'null' => 
      array (
        'driver' => 'null',
      ),
    ),
  ),
  'cors' => 
  array (
    'paths' => 
    array (
      0 => 'api/*',
      1 => 'sanctum/csrf-cookie',
    ),
    'allowed_methods' => 
    array (
      0 => '*',
    ),
    'allowed_origins' => 
    array (
      0 => '*',
    ),
    'allowed_origins_patterns' => 
    array (
    ),
    'allowed_headers' => 
    array (
      0 => '*',
    ),
    'exposed_headers' => 
    array (
    ),
    'max_age' => 0,
    'supports_credentials' => false,
  ),
  'app' => 
  array (
    'name' => 'Laravel',
    'env' => 'local',
    'debug' => true,
    'url' => 'http://localhost',
    'frontend_url' => 'http://localhost:3000',
    'asset_url' => NULL,
    'timezone' => 'UTC',
    'locale' => 'en',
    'fallback_locale' => 'en',
    'faker_locale' => 'en_US',
    'cipher' => 'AES-256-CBC',
    'key' => 'base64:OY3IJJpTTJKSt277Tc9z2tVbpreupjXvldl9l1xGK0s=',
    'previous_keys' => 
    array (
    ),
    'maintenance' => 
    array (
      'driver' => 'file',
      'store' => 'database',
    ),
    'providers' => 
    array (
      0 => 'Illuminate\\Auth\\AuthServiceProvider',
      1 => 'Illuminate\\Broadcasting\\BroadcastServiceProvider',
      2 => 'Illuminate\\Bus\\BusServiceProvider',
      3 => 'Illuminate\\Cache\\CacheServiceProvider',
      4 => 'Illuminate\\Foundation\\Providers\\ConsoleSupportServiceProvider',
      5 => 'Illuminate\\Concurrency\\ConcurrencyServiceProvider',
      6 => 'Illuminate\\Cookie\\CookieServiceProvider',
      7 => 'Illuminate\\Database\\DatabaseServiceProvider',
      8 => 'Illuminate\\Encryption\\EncryptionServiceProvider',
      9 => 'Illuminate\\Filesystem\\FilesystemServiceProvider',
      10 => 'Illuminate\\Foundation\\Providers\\FoundationServiceProvider',
      11 => 'Illuminate\\Hashing\\HashServiceProvider',
      12 => 'Illuminate\\Mail\\MailServiceProvider',
      13 => 'Illuminate\\Notifications\\NotificationServiceProvider',
      14 => 'Illuminate\\Pagination\\PaginationServiceProvider',
      15 => 'Illuminate\\Auth\\Passwords\\PasswordResetServiceProvider',
      16 => 'Illuminate\\Pipeline\\PipelineServiceProvider',
      17 => 'Illuminate\\Queue\\QueueServiceProvider',
      18 => 'Illuminate\\Redis\\RedisServiceProvider',
      19 => 'Illuminate\\Session\\SessionServiceProvider',
      20 => 'Illuminate\\Translation\\TranslationServiceProvider',
      21 => 'Illuminate\\Validation\\ValidationServiceProvider',
      22 => 'Illuminate\\View\\ViewServiceProvider',
      23 => 'App\\Providers\\AppServiceProvider',
    ),
    'aliases' => 
    array (
      'App' => 'Illuminate\\Support\\Facades\\App',
      'Arr' => 'Illuminate\\Support\\Arr',
      'Artisan' => 'Illuminate\\Support\\Facades\\Artisan',
      'Auth' => 'Illuminate\\Support\\Facades\\Auth',
      'Benchmark' => 'Illuminate\\Support\\Benchmark',
      'Blade' => 'Illuminate\\Support\\Facades\\Blade',
      'Broadcast' => 'Illuminate\\Support\\Facades\\Broadcast',
      'Bus' => 'Illuminate\\Support\\Facades\\Bus',
      'Cache' => 'Illuminate\\Support\\Facades\\Cache',
      'Concurrency' => 'Illuminate\\Support\\Facades\\Concurrency',
      'Config' => 'Illuminate\\Support\\Facades\\Config',
      'Context' => 'Illuminate\\Support\\Facades\\Context',
      'Cookie' => 'Illuminate\\Support\\Facades\\Cookie',
      'Crypt' => 'Illuminate\\Support\\Facades\\Crypt',
      'Date' => 'Illuminate\\Support\\Facades\\Date',
      'DB' => 'Illuminate\\Support\\Facades\\DB',
      'Eloquent' => 'Illuminate\\Database\\Eloquent\\Model',
      'Event' => 'Illuminate\\Support\\Facades\\Event',
      'File' => 'Illuminate\\Support\\Facades\\File',
      'Gate' => 'Illuminate\\Support\\Facades\\Gate',
      'Hash' => 'Illuminate\\Support\\Facades\\Hash',
      'Http' => 'Illuminate\\Support\\Facades\\Http',
      'Js' => 'Illuminate\\Support\\Js',
      'Lang' => 'Illuminate\\Support\\Facades\\Lang',
      'Log' => 'Illuminate\\Support\\Facades\\Log',
      'Mail' => 'Illuminate\\Support\\Facades\\Mail',
      'Notification' => 'Illuminate\\Support\\Facades\\Notification',
      'Number' => 'Illuminate\\Support\\Number',
      'Password' => 'Illuminate\\Support\\Facades\\Password',
      'Process' => 'Illuminate\\Support\\Facades\\Process',
      'Queue' => 'Illuminate\\Support\\Facades\\Queue',
      'RateLimiter' => 'Illuminate\\Support\\Facades\\RateLimiter',
      'Redirect' => 'Illuminate\\Support\\Facades\\Redirect',
      'Request' => 'Illuminate\\Support\\Facades\\Request',
      'Response' => 'Illuminate\\Support\\Facades\\Response',
      'Route' => 'Illuminate\\Support\\Facades\\Route',
      'Schedule' => 'Illuminate\\Support\\Facades\\Schedule',
      'Schema' => 'Illuminate\\Support\\Facades\\Schema',
      'Session' => 'Illuminate\\Support\\Facades\\Session',
      'Storage' => 'Illuminate\\Support\\Facades\\Storage',
      'Str' => 'Illuminate\\Support\\Str',
      'Uri' => 'Illuminate\\Support\\Uri',
      'URL' => 'Illuminate\\Support\\Facades\\URL',
      'Validator' => 'Illuminate\\Support\\Facades\\Validator',
      'View' => 'Illuminate\\Support\\Facades\\View',
      'Vite' => 'Illuminate\\Support\\Facades\\Vite',
    ),
  ),
  'auth' => 
  array (
    'defaults' => 
    array (
      'guard' => 'web',
      'passwords' => 'users',
    ),
    'guards' => 
    array (
      'web' => 
      array (
        'driver' => 'session',
        'provider' => 'users',
      ),
      'starpmaminul' => 
      array (
        'driver' => 'session',
        'provider' => 'starpmaminul_users',
      ),
    ),
    'providers' => 
    array (
      'users' => 
      array (
        'driver' => 'eloquent',
        'model' => 'App\\Models\\User',
      ),
      'starpmaminul_users' => 
      array (
        'driver' => 'eloquent',
        'model' => 'App\\Models\\StarPmAminul\\User',
      ),
    ),
    'passwords' => 
    array (
      'users' => 
      array (
        'provider' => 'users',
        'table' => 'password_reset_tokens',
        'expire' => 60,
        'throttle' => 60,
      ),
    ),
    'password_timeout' => 10800,
  ),
  'cache' => 
  array (
    'default' => 'database',
    'stores' => 
    array (
      'array' => 
      array (
        'driver' => 'array',
        'serialize' => false,
      ),
      'session' => 
      array (
        'driver' => 'session',
        'key' => '_cache',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'connection' => NULL,
        'table' => 'cache',
        'lock_connection' => NULL,
        'lock_table' => NULL,
      ),
      'file' => 
      array (
        'driver' => 'file',
        'path' => '/Applications/XAMPP/xamppfiles/htdocs/laravel/ITQANConsulting/storage/framework/cache/data',
        'lock_path' => '/Applications/XAMPP/xamppfiles/htdocs/laravel/ITQANConsulting/storage/framework/cache/data',
      ),
      'storage' => 
      array (
        'driver' => 'storage',
        'disk' => NULL,
        'path' => 'framework/cache/data',
      ),
      'memcached' => 
      array (
        'driver' => 'memcached',
        'persistent_id' => NULL,
        'sasl' => 
        array (
          0 => NULL,
          1 => NULL,
        ),
        'options' => 
        array (
        ),
        'servers' => 
        array (
          0 => 
          array (
            'host' => '127.0.0.1',
            'port' => 11211,
            'weight' => 100,
          ),
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'cache',
        'lock_connection' => 'default',
      ),
      'dynamodb' => 
      array (
        'driver' => 'dynamodb',
        'key' => '',
        'secret' => '',
        'region' => 'us-east-1',
        'table' => 'cache',
        'endpoint' => NULL,
      ),
      'octane' => 
      array (
        'driver' => 'octane',
      ),
      'failover' => 
      array (
        'driver' => 'failover',
        'stores' => 
        array (
          0 => 'database',
          1 => 'array',
        ),
      ),
    ),
    'prefix' => 'laravel-cache-',
    'serializable_classes' => false,
  ),
  'database' => 
  array (
    'default' => 'mysql',
    'connections' => 
    array (
      'sqlite' => 
      array (
        'driver' => 'sqlite',
        'url' => NULL,
        'database' => 'ITQAN_NEW',
        'prefix' => '',
        'foreign_key_constraints' => true,
        'busy_timeout' => NULL,
        'journal_mode' => NULL,
        'synchronous' => NULL,
        'transaction_mode' => 'DEFERRED',
      ),
      'mysql' => 
      array (
        'driver' => 'mysql',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'ITQAN_NEW',
        'username' => 'root',
        'password' => '',
        'unix_socket' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'prefix_indexes' => true,
        'strict' => true,
        'engine' => NULL,
        'options' => 
        array (
        ),
      ),
      'mariadb' => 
      array (
        'driver' => 'mariadb',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'ITQAN_NEW',
        'username' => 'root',
        'password' => '',
        'unix_socket' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'prefix_indexes' => true,
        'strict' => true,
        'engine' => NULL,
        'options' => 
        array (
        ),
      ),
      'pgsql' => 
      array (
        'driver' => 'pgsql',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'ITQAN_NEW',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
        'search_path' => 'public',
        'sslmode' => 'prefer',
      ),
      'sqlsrv' => 
      array (
        'driver' => 'sqlsrv',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'ITQAN_NEW',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
      ),
      'starpmaminul' => 
      array (
        'driver' => 'sqlite',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => '/Applications/XAMPP/xamppfiles/htdocs/laravel/ITQANConsulting/database/starpmaminul.sqlite',
        'username' => 'root',
        'password' => '',
        'unix_socket' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'prefix_indexes' => true,
        'strict' => true,
        'engine' => NULL,
        'foreign_key_constraints' => true,
        'busy_timeout' => NULL,
        'journal_mode' => NULL,
        'synchronous' => NULL,
        'transaction_mode' => 'DEFERRED',
        'options' => 
        array (
        ),
      ),
    ),
    'migrations' => 
    array (
      'table' => 'migrations',
      'update_date_on_publish' => true,
    ),
    'redis' => 
    array (
      'client' => 'phpredis',
      'options' => 
      array (
        'cluster' => 'redis',
        'prefix' => 'laravel-database-',
        'persistent' => false,
      ),
      'default' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'username' => NULL,
        'password' => NULL,
        'port' => '6379',
        'database' => '0',
        'max_retries' => 3,
        'backoff_algorithm' => 'decorrelated_jitter',
        'backoff_base' => 100,
        'backoff_cap' => 1000,
      ),
      'cache' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'username' => NULL,
        'password' => NULL,
        'port' => '6379',
        'database' => '1',
        'max_retries' => 3,
        'backoff_algorithm' => 'decorrelated_jitter',
        'backoff_base' => 100,
        'backoff_cap' => 1000,
      ),
    ),
  ),
  'filesystems' => 
  array (
    'default' => 'local',
    'disks' => 
    array (
      'local' => 
      array (
        'driver' => 'local',
        'root' => '/Applications/XAMPP/xamppfiles/htdocs/laravel/ITQANConsulting/storage/app/private',
        'serve' => false,
        'throw' => false,
        'report' => false,
      ),
      'public' => 
      array (
        'driver' => 'local',
        'root' => '/Applications/XAMPP/xamppfiles/htdocs/laravel/ITQANConsulting/storage/app/public',
        'url' => 'http://localhost/storage',
        'visibility' => 'public',
        'throw' => false,
        'report' => false,
      ),
      's3' => 
      array (
        'driver' => 's3',
        'key' => '',
        'secret' => '',
        'region' => 'us-east-1',
        'bucket' => '',
        'url' => NULL,
        'endpoint' => NULL,
        'use_path_style_endpoint' => false,
        'throw' => false,
        'report' => false,
      ),
    ),
    'links' => 
    array (
      '/Applications/XAMPP/xamppfiles/htdocs/laravel/ITQANConsulting/public/storage' => '/Applications/XAMPP/xamppfiles/htdocs/laravel/ITQANConsulting/storage/app/public',
    ),
  ),
  'itqan' => 
  array (
    'site' => 
    array (
      'name' => 'ITQAN Consulting',
      'mark' => 'IC',
      'tagline' => 'Sincere Services. Lasting Results.',
      'email' => 'hello@itqanconsulting.com',
      'address' => 'Dhaka, Bangladesh',
      'description' => 'Practical consulting, technology, and delivery support for businesses in Bangladesh and beyond.',
      'primary_cta' => 
      array (
        'text' => 'Book a Consultation',
        'route' => 'contact',
      ),
    ),
    'navigation' => 
    array (
      0 => 
      array (
        'label' => 'Home',
        'route' => 'home',
      ),
      1 => 
      array (
        'label' => 'Services',
        'route' => 'services',
      ),
      2 => 
      array (
        'label' => 'Works',
        'route' => 'works',
      ),
      3 => 
      array (
        'label' => 'Catalog',
        'route' => 'catalog',
      ),
      4 => 
      array (
        'label' => 'About',
        'route' => 'about',
      ),
      5 => 
      array (
        'label' => 'Contact',
        'route' => 'contact',
      ),
    ),
    'social_links' => 
    array (
      0 => 
      array (
        'platform' => 'linkedin',
        'label' => 'ITQAN on LinkedIn',
        'url' => '#',
        'svg' => '<path d="M4.98 3.5C4.98 4.88 3.86 6 2.5 6S0 4.88 0 3.5 1.12 1 2.5 1s2.48 1.12 2.48 2.5zM.36 8.1h4.28V23H.36V8.1zM7.55 8.1h4.1v2.04h.06c.57-1.08 1.96-2.22 4.03-2.22 4.31 0 5.1 2.84 5.1 6.53V23h-4.27v-7.58c0-1.8-.03-4.12-2.51-4.12-2.51 0-2.9 1.96-2.9 3.99V23H7.55V8.1z"/>',
      ),
      1 => 
      array (
        'platform' => 'facebook',
        'label' => 'ITQAN on Facebook',
        'url' => '#',
        'svg' => '<path d="M22 12.06C22 6.5 17.52 2 12 2S2 6.5 2 12.06c0 5.02 3.66 9.18 8.44 9.94v-7.03H7.9v-2.91h2.54V9.85c0-2.52 1.49-3.91 3.77-3.91 1.09 0 2.23.2 2.23.2v2.47h-1.25c-1.24 0-1.63.77-1.63 1.57v1.88h2.78l-.44 2.91h-2.34V22C18.34 21.24 22 17.08 22 12.06z"/>',
      ),
      2 => 
      array (
        'platform' => 'youtube',
        'label' => 'ITQAN on YouTube',
        'url' => '#',
        'svg' => '<path d="M23.5 6.2a3 3 0 0 0-2.1-2.12C19.55 3.58 12 3.58 12 3.58s-7.55 0-9.4.5A3 3 0 0 0 .5 6.2 31.5 31.5 0 0 0 0 12a31.5 31.5 0 0 0 .5 5.8 3 3 0 0 0 2.1 2.12c1.85.5 9.4.5 9.4.5s7.55 0 9.4-.5a3 3 0 0 0 2.1-2.12A31.5 31.5 0 0 0 24 12a31.5 31.5 0 0 0-.5-5.8zM9.75 15.54V8.46L16 12l-6.25 3.54z"/>',
      ),
      3 => 
      array (
        'platform' => 'whatsapp',
        'label' => 'ITQAN on WhatsApp',
        'url' => '#',
        'svg' => '<path d="M20.52 3.48A11.9 11.9 0 0 0 12.06 0C5.49 0 .14 5.34.14 11.91c0 2.1.55 4.16 1.6 5.97L0 24l6.3-1.65a11.9 11.9 0 0 0 5.76 1.47h.01c6.57 0 11.92-5.34 11.92-11.91a11.86 11.86 0 0 0-3.47-8.43zM12.07 21.8h-.01a9.88 9.88 0 0 1-5.04-1.38l-.36-.21-3.74.98 1-3.64-.24-.37a9.86 9.86 0 0 1-1.51-5.27c0-5.46 4.44-9.9 9.91-9.9a9.85 9.85 0 0 1 7 2.9 9.85 9.85 0 0 1 2.9 7c0 5.46-4.45 9.89-9.91 9.89zm5.43-7.4c-.3-.15-1.76-.87-2.03-.97-.27-.1-.47-.15-.67.15-.2.3-.77.97-.94 1.17-.17.2-.35.22-.64.07-.3-.15-1.25-.46-2.38-1.47a8.9 8.9 0 0 1-1.65-2.05c-.17-.3-.02-.46.13-.6.13-.13.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.07-.15-.67-1.62-.92-2.22-.24-.58-.49-.5-.67-.5h-.57c-.2 0-.52.07-.79.37-.27.3-1.04 1.02-1.04 2.49s1.07 2.89 1.22 3.09c.15.2 2.1 3.2 5.08 4.49.71.31 1.26.49 1.69.63.71.23 1.36.2 1.88.12.57-.08 1.76-.72 2-1.42.25-.7.25-1.3.17-1.42-.07-.13-.27-.2-.57-.35z"/>',
      ),
    ),
    'footer' => 
    array (
      'service_links' => 
      array (
        0 => 'Consulting',
        1 => 'Software Development',
        2 => 'ERP',
        3 => 'Project Management',
        4 => 'Business Automation',
        5 => 'Training',
      ),
      'bottom_left' => 'Consulting | Software Development | ERP | Project Management | Business Automation | Training',
      'copyright' => '© 2026 ITQAN Consulting.',
    ),
    'collections' => 
    array (
      'testimonials' => 
      array (
        0 => 
        array (
          'title' => 'That saved us a lot of confusion.',
          'text' => 'ITQAN helped us organize our system requirements in a way the business and technical team both understood.',
          'author' => 'Client Representative',
          'role' => 'Operations Team',
          'project' => 'Business clarity',
        ),
        1 => 
        array (
          'title' => 'They understand the business first.',
          'text' => 'They do not just talk about software. They try to understand the actual business first. That made the work easier.',
          'author' => 'Business Owner',
          'role' => 'Trading Company',
          'project' => 'Consulting',
        ),
        2 => 
        array (
          'title' => 'The scope was clear.',
          'text' => 'The communication was clear. The scope was clear. We knew what was being done and why.',
          'author' => 'Project Stakeholder',
          'role' => 'Service Business',
          'project' => 'Project delivery',
        ),
      ),
      'works' => 
      array (
        0 => 
        array (
          'title' => 'Fleetman PLUS',
          'pill' => 'Software / Fleet',
          'preview_pill' => 'Fleet',
          'description' => 'Vehicle, driver, fuel, contract, and reporting control for fleet operations.',
          'preview_description' => 'Fleet and operations management system for vehicle, driver, fuel, contract, and reporting control.',
          'categories' => 
          array (
            0 => 'software',
            1 => 'process',
            2 => 'consulting',
          ),
          'tags' => 
          array (
            0 => 'Operations',
            1 => 'Reporting',
            2 => 'Workflow',
          ),
        ),
        1 => 
        array (
          'title' => 'HisebGhor',
          'pill' => 'Accounting',
          'preview_pill' => 'Accounting',
          'description' => 'Simple accounting system concept for small businesses with transaction rules and party balances.',
          'preview_description' => 'Simple accounting system concept for small businesses with transaction rules, party balances, and reports.',
          'categories' => 
          array (
            0 => 'software',
            1 => 'erp',
            2 => 'consulting',
          ),
          'tags' => 
          array (
            0 => 'Rules',
            1 => 'Reports',
            2 => 'SME',
          ),
        ),
        2 => 
        array (
          'title' => 'NextPlay Sportswear',
          'pill' => 'E-commerce',
          'preview_pill' => 'E-commerce',
          'description' => 'Product category, PDP, bulk quote, and custom sportswear ordering experience.',
          'preview_description' => 'E-commerce experience for custom sportswear, bulk orders, product pages, and category structure.',
          'categories' => 
          array (
            0 => 'ecommerce',
            1 => 'website',
            2 => 'software',
          ),
          'tags' => 
          array (
            0 => 'UX',
            1 => 'Catalog',
            2 => 'Bulk order',
          ),
        ),
        3 => 
        array (
          'title' => 'Business Website Revamp',
          'pill' => 'Website Revamp',
          'preview_pill' => 'Website',
          'description' => 'Website planning, content structure, and UI direction for service businesses and personal brands.',
          'preview_description' => 'Website planning, content structure, and UI direction for service businesses and personal brands.',
          'categories' => 
          array (
            0 => 'website',
            1 => 'consulting',
            2 => 'process',
          ),
          'tags' => 
          array (
            0 => 'Content',
            1 => 'UI',
            2 => 'Brand',
          ),
        ),
      ),
      'work_filters' => 
      array (
        0 => 
        array (
          'label' => 'All',
          'value' => 'all',
        ),
        1 => 
        array (
          'label' => 'Software',
          'value' => 'software',
        ),
        2 => 
        array (
          'label' => 'ERP',
          'value' => 'erp',
        ),
        3 => 
        array (
          'label' => 'Website',
          'value' => 'website',
        ),
        4 => 
        array (
          'label' => 'E-commerce',
          'value' => 'ecommerce',
        ),
        5 => 
        array (
          'label' => 'Process',
          'value' => 'process',
        ),
        6 => 
        array (
          'label' => 'Training',
          'value' => 'training',
        ),
        7 => 
        array (
          'label' => 'Consulting',
          'value' => 'consulting',
        ),
      ),
      'services' => 
      array (
        0 => 
        array (
          'badge' => '01',
          'title' => 'Consulting & Business Clarity',
          'intro' => 'For businesses with unclear processes, scattered records, delayed reports, or weak control.',
          'points' => 
          array (
            0 => 'Business process analysis',
            1 => 'Requirement analysis',
            2 => 'SOP and workflow documentation',
            3 => 'Reporting structure',
          ),
          'button' => 'Discuss Consulting Work',
        ),
        1 => 
        array (
          'badge' => '02',
          'title' => 'Project & Product Support',
          'intro' => 'For teams that need better planning, scope control, priorities, tracking, and delivery coordination.',
          'points' => 
          array (
            0 => 'Project management support',
            1 => 'Product planning',
            2 => 'Delivery tracking',
            3 => 'Project rescue or audit',
          ),
          'button' => 'Improve Delivery',
        ),
        2 => 
        array (
          'badge' => '03',
          'title' => 'Software & Web Development',
          'intro' => 'For businesses that need structured digital tools, web platforms, or custom systems that match the work.',
          'points' => 
          array (
            0 => 'Business websites',
            1 => 'Web applications',
            2 => 'Dashboards and portals',
            3 => 'Custom business systems',
          ),
          'button' => 'Plan a System',
        ),
        3 => 
        array (
          'badge' => '04',
          'title' => 'ERP & Automation',
          'intro' => 'For teams that want less manual work, better process flow, and more reliable business visibility.',
          'points' => 
          array (
            0 => 'ERP planning',
            1 => 'Module design',
            2 => 'Business automation',
            3 => 'Reporting automation',
          ),
          'button' => 'Explore Automation',
        ),
        4 => 
        array (
          'badge' => '05',
          'title' => 'Training & Coaching',
          'intro' => 'For companies that want their people to work with better structure, tools, and confidence.',
          'points' => 
          array (
            0 => 'Project management training',
            1 => 'Business analysis training',
            2 => 'Tool-based training',
            3 => 'Team capacity building',
          ),
          'button' => 'Train Your Team',
        ),
        5 => 
        array (
          'badge' => '06',
          'title' => 'Dedicated Team Support',
          'intro' => 'For businesses that need reliable delivery support through dedicated people across key roles.',
          'points' => 
          array (
            0 => 'Offshore resource support',
            1 => 'Dedicated developers',
            2 => 'PM / BA support',
            3 => 'Long-term delivery team setup',
          ),
          'button' => 'Build a Team',
        ),
      ),
      'service_faqs' => 
      array (
        0 => 
        array (
          'question' => 'How do we know which ITQAN service is right for us?',
          'summary' => 'You do not need to know the exact service name before contacting us.',
          'answer' => 
          array (
            0 => 'You can simply share what is happening in your business. Maybe the process is messy, reporting is weak, projects are delayed, people are doing too much manual work, or your current system is not helping enough.',
            1 => 'We will help you understand the issue first, then suggest the service or support that fits best.',
          ),
        ),
        1 => 
        array (
          'question' => 'Do we need to have a clear brief before starting?',
          'summary' => 'No.',
          'answer' => 
          array (
            0 => 'Many clients come with a problem, not a ready brief. That is normal.',
            1 => 'ITQAN helps organize the problem, ask the right questions, understand the business situation, and prepare a clear direction before execution starts.',
          ),
        ),
        2 => 
        array (
          'question' => 'Can ITQAN help if our business process is not documented?',
          'summary' => 'Yes.',
          'answer' => 
          array (
            0 => 'In fact, this is one of the common reasons clients work with us.',
            1 => 'We can study how the work is currently done, speak with the relevant people, identify gaps, and prepare practical documents, workflows, or system requirements based on the real business process.',
          ),
        ),
        3 => 
        array (
          'question' => 'Does ITQAN only provide consulting, or also implementation support?',
          'summary' => 'ITQAN provides both consulting and execution support.',
          'answer' => 
          array (
            0 => 'Depending on the need, we can help with analysis, planning, documentation, system design, software development, ERP support, automation, project management, training, and implementation guidance.',
            1 => 'The goal is not just to give advice. The goal is to help the work move forward.',
          ),
        ),
        4 => 
        array (
          'question' => 'Can ITQAN work with our existing team or vendor?',
          'summary' => 'Yes.',
          'answer' => 
          array (
            0 => 'We can work with your internal team, management team, technical team, or existing software vendor.',
            1 => 'Sometimes we act as an advisor. Sometimes we support execution. Sometimes we help both sides understand the business requirement better so the work becomes clearer and less delayed.',
          ),
        ),
        5 => 
        array (
          'question' => 'What kind of deliverables can we expect?',
          'summary' => 'Deliverables depend on the type of work.',
          'answer' => 
          array (
            0 => 'Common outputs may include process maps, requirement documents, audit findings, improvement plans, project plans, dashboards, reports, system screen flows, training materials, software modules, or implementation support notes.',
            1 => 'Before starting, we will clarify what will be delivered.',
          ),
        ),
        6 => 
        array (
          'question' => 'How does ITQAN usually start a project?',
          'summary' => 'We usually start with a discussion.',
          'answer' => 
          array (
            0 => 'We usually start with a discussion to understand the business problem, current process, team structure, tools, and expected result.',
            1 => 'After that, we define the scope, approach, timeline, and deliverables.',
            2 => 'We try to keep the starting point simple and practical.',
          ),
        ),
        7 => 
        array (
          'question' => 'Will ITQAN suggest software for every problem?',
          'summary' => 'No.',
          'answer' => 
          array (
            0 => 'We do not push software where a simpler process, better reporting, training, or clearer responsibility can solve the issue.',
            1 => 'Technology is useful only when it fits the business need. We focus on the problem first, then decide what kind of solution makes sense.',
          ),
        ),
        8 => 
        array (
          'question' => 'Can ITQAN support small and growing businesses?',
          'summary' => 'Yes.',
          'answer' => 
          array (
            0 => 'ITQAN works with businesses that need practical support, even if they are not large companies yet.',
            1 => 'For growing businesses, the focus is usually on creating structure, reducing confusion, improving tracking, and preparing the business for better systems.',
          ),
        ),
        9 => 
        array (
          'question' => 'What outcome should we expect after working with ITQAN?',
          'summary' => 'You should have better clarity, better structure, and a more practical way to manage the work.',
          'answer' => 
          array (
            0 => 'The expected outcome may include clearer processes, better reporting, improved delivery control, reduced manual work, better system usage, or stronger decision-making.',
            1 => 'The exact result depends on the service, but the direction is always the same: make the work easier to understand, manage, and improve.',
          ),
        ),
      ),
      'catalog_pages' => 
      array (
        0 => 
        array (
          'type' => 'image',
          'title' => 'Cover',
          'kicker' => 'ITQAN Consulting',
          'body' => 'Practical consulting, software planning, delivery support, ERP, automation, websites, and training under one roof.',
        ),
        1 => 
        array (
          'type' => 'image',
          'title' => 'Who We Are',
          'kicker' => 'Business clarity',
          'body' => 'We work with businesses that need clear guidance, better systems, and reliable execution.',
        ),
        2 => 
        array (
          'type' => 'image',
          'title' => 'What We Do',
          'kicker' => 'Services',
          'body' => 'Process analysis, project support, software development, AI strategy, training, and dedicated resources.',
        ),
        3 => 
        array (
          'type' => 'video',
          'title' => 'Founder Message',
          'kicker' => 'Short video page',
          'body' => 'This page is ready for an MP4 catalog page. Add a src and poster in the data array when the real media is uploaded.',
        ),
        4 => 
        array (
          'type' => 'image',
          'title' => 'Our Method',
          'kicker' => 'Listen. Map. Plan. Build. Support.',
          'body' => 'First we understand. Then we build. The method keeps scope clear and delivery practical.',
        ),
        5 => 
        array (
          'type' => 'image',
          'title' => 'Contact ITQAN',
          'kicker' => 'Next step',
          'body' => 'Bring the messy business problem. We will help make it clear.',
        ),
      ),
      'contact_options' => 
      array (
        'problems' => 
        array (
          0 => 'Business process',
          1 => 'Project delivery',
          2 => 'Software or website',
          3 => 'ERP or automation',
          4 => 'Reporting and data',
          5 => 'Team capability',
        ),
        'needs' => 
        array (
          0 => 'Consulting first',
          1 => 'Plan and manage',
          2 => 'Design and build',
          3 => 'Review current system',
          4 => 'Train the team',
          5 => 'Not sure yet',
        ),
        'methods' => 
        array (
          0 => 'WhatsApp',
          1 => 'Email',
          2 => 'Phone call',
          3 => 'Online meeting',
        ),
        'budgets' => 
        array (
          0 => 'Not decided yet',
          1 => 'Under BDT 100,000',
          2 => 'BDT 100,000 – 300,000',
          3 => 'BDT 300,000 – 800,000',
          4 => 'Above BDT 800,000',
        ),
      ),
    ),
    'pages' => 
    array (
      'home' => 
      array (
        'title' => 'ITQAN Consulting',
        'meta_description' => 'ITQAN Consulting provides practical consulting, software planning, project delivery, automation, ERP, websites, and training support.',
        'hero' => 
        array (
          'label' => 'ITQAN Consulting',
          'title' => 'When business feels <span class="red-text">messy</span>, we help make it <span class="blue-text">clear.</span>',
          'description' => 'ITQAN Consulting supports businesses with practical consulting, software planning, project delivery, automation, ERP, websites, and team support.',
          'chips' => 
          array (
            0 => 'No noise.',
            1 => 'No over-promising.',
            2 => 'Honest execution.',
          ),
          'buttons' => 
          array (
            0 => 
            array (
              'text' => 'Start a Conversation',
              'route' => 'contact',
              'class' => 'blue',
            ),
            1 => 
            array (
              'text' => 'Explore Services',
              'route' => 'services',
              'class' => '',
            ),
          ),
          'social_label' => 'Connect with ITQAN',
          'ticker' => 
          array (
            0 => 'Business process clarity',
            1 => 'Requirements, timeline, and ownership',
            2 => 'Useful dashboards and reporting',
            3 => 'Team alignment and delivery control',
            4 => 'Automation that reduces manual work',
            5 => 'ERP that fits people, data, and business',
            6 => 'Clear execution from idea to support',
          ),
        ),
        'founder' => 
        array (
          'label' => 'From the Founder',
          'title' => 'We started ITQAN because many businesses do not fail from lack of effort. They fail from lack of clarity.',
          'paragraphs' => 
          array (
            0 => 'I have worked with software teams, business owners, operations teams, product teams, and project teams for many years. One thing is clear.',
            1 => 'Most problems are not only technical. Sometimes the process is unclear. Sometimes the team is confused. Sometimes the software does not match the real work.',
            2 => 'ITQAN Consulting was created to solve these problems in a practical way. We listen first. We understand the business. Then we help with planning, documentation, software, automation, team support, and delivery.',
          ),
          'name' => 'Md Aminul Islam, PMP, CSM',
          'role' => 'Founder & Chief Consultant, ITQAN Consulting',
          'button' => 
          array (
            'text' => 'View my digital resume',
            'route' => 'starpmaminul.portfolio',
            'url' => NULL,
          ),
        ),
        'who' => 
        array (
          'label' => 'Why ITQAN Exists',
          'title' => 'Hard work should not stay trapped inside a messy system.',
          'lead' => 'As each problem enters view, the visual changes from scattered information into an organized workflow.',
          'cards' => 
          array (
            0 => 
            array (
              'num' => '01',
              'title' => 'The work is happening, but nobody sees the full picture.',
              'text' => 'Information moves through calls, messages, files, and individual knowledge. Management sees the result late.',
              'response' => 'We map the process and make the complete workflow visible.',
              'stage_label' => 'The full picture becomes visible',
            ),
            1 => 
            array (
              'num' => '02',
              'title' => 'The team depends on memory, calls, and scattered files.',
              'text' => 'Good people keep the operation running, but repeated follow-up makes growth difficult.',
              'response' => 'We organize the work into practical records, ownership, and systems.',
              'stage_label' => 'Work becomes a shared system',
            ),
            2 => 
            array (
              'num' => '03',
              'title' => 'Software is built, but people do not use it properly.',
              'text' => 'The system may be technically correct, yet the user journey does not match the real business routine.',
              'response' => 'We focus on adoption, training, usability, and real business fit.',
              'stage_label' => 'Software fits the people using it',
            ),
            3 => 
            array (
              'num' => '04',
              'title' => 'Management does not get the right reports at the right time.',
              'text' => 'Data exists, but it does not answer the questions that leaders need to act on.',
              'response' => 'We design reporting around practical decisions, not decorative dashboards.',
              'stage_label' => 'Decisions get useful information',
            ),
          ),
        ),
        'problems' => 
        array (
          'label' => 'Interactive Clarity Check',
          'title' => 'Where does the work feel unclear?',
          'lead' => 'Choose the situation that sounds familiar. The response changes instantly and shows a practical starting point.',
          'items' => 
          array (
            0 => 
            array (
              'problem' => 'Our process is undocumented',
              'summary' => 'Important work depends on people remembering what to do, when to do it, and who should approve it.',
              'services' => 
              array (
                0 => 'Process interviews',
                1 => 'Workflow mapping',
                2 => 'Roles and responsibility',
                3 => 'Practical documentation',
              ),
            ),
            1 => 
            array (
              'problem' => 'Projects keep getting delayed',
              'summary' => 'The team is working, but scope, priority, dependencies, and decisions are difficult to control.',
              'services' => 
              array (
                0 => 'Project audit',
                1 => 'Scope review',
                2 => 'Delivery planning',
                3 => 'Progress reporting',
              ),
            ),
            2 => 
            array (
              'problem' => 'Reports take too much time',
              'summary' => 'Management needs answers, but data is scattered and reporting requires repeated manual preparation.',
              'services' => 
              array (
                0 => 'Data mapping',
                1 => 'Dashboard planning',
                2 => 'Report structure',
                3 => 'Automation opportunities',
              ),
            ),
            3 => 
            array (
              'problem' => 'Too much work is manual',
              'summary' => 'People repeat the same entries, approvals, reminders, and follow-ups across calls, files, and messages.',
              'services' => 
              array (
                0 => 'Manual task review',
                1 => 'Automation map',
                2 => 'Priority matrix',
                3 => 'Implementation plan',
              ),
            ),
            4 => 
            array (
              'problem' => 'Software does not match the business',
              'summary' => 'A system exists, but the real work happens somewhere else because users cannot follow the intended flow.',
              'services' => 
              array (
                0 => 'User interviews',
                1 => 'Workflow-fit review',
                2 => 'Adoption planning',
                3 => 'Improvement backlog',
              ),
            ),
            5 => 
            array (
              'problem' => 'We are unsure what system we need',
              'summary' => 'The business wants technology, but the right scope, budget, priority, and implementation path are not clear yet.',
              'services' => 
              array (
                0 => 'Discovery workshop',
                1 => 'Solution options',
                2 => 'Scope definition',
                3 => 'Delivery roadmap',
              ),
            ),
          ),
        ),
        'services_preview' => 
        array (
          'label' => 'Services Explorer',
          'title' => 'Support from problem understanding to practical execution.',
          'lead' => 'Explore the services that can help clarify the work, improve delivery, and build the right solution.',
          'items' => 
          array (
            0 => 
            array (
              'num' => '01',
              'title' => 'Consulting & Business Clarity',
              'text' => 'For businesses where the work is real, but the process, responsibility, scope, or system direction is not clear enough.',
              'common_problem' => 'Scattered process, unclear ownership, and repeated follow-up.',
              'deliverables' => 'Process maps, requirements, scope, action plan, and decision notes.',
            ),
            1 => 
            array (
              'num' => '02',
              'title' => 'Project & Product Support',
              'text' => 'For owners and teams that need stronger planning, prioritization, coordination, progress control, and delivery guidance.',
              'common_problem' => 'Late delivery, shifting scope, hidden dependencies, and weak reporting.',
              'deliverables' => 'Roadmap, backlog, project plan, audit, status system, and delivery support.',
            ),
            2 => 
            array (
              'num' => '03',
              'title' => 'Software & Web Development',
              'text' => 'For businesses that need custom websites, web applications, dashboards, portals, or business systems designed around real users.',
              'common_problem' => 'Generic tools do not match the business or customer journey.',
              'deliverables' => 'UX direction, system design, development, testing, and launch support.',
            ),
            3 => 
            array (
              'num' => '04',
              'title' => 'ERP & Automation',
              'text' => 'For growing companies that need connected records, structured approvals, better reporting, and less manual repetition.',
              'common_problem' => 'Departments work separately and information does not flow well.',
              'deliverables' => 'ERP scope, module mapping, automation design, and implementation support.',
            ),
            4 => 
            array (
              'num' => '05',
              'title' => 'Training & Coaching',
              'text' => 'For teams and professionals who need practical learning in project management, business analysis, tools, AI, and delivery discipline.',
              'common_problem' => 'Knowledge exists, but day-to-day application remains weak.',
              'deliverables' => 'Workshops, coaching, templates, exercises, and team learning plans.',
            ),
            5 => 
            array (
              'num' => '06',
              'title' => 'Dedicated Team Support',
              'text' => 'For organizations that need reliable project, product, design, development, QA, or operational capacity for ongoing work.',
              'common_problem' => 'Hiring takes time and existing teams cannot carry every priority.',
              'deliverables' => 'Role planning, team setup, managed resources, and delivery reporting.',
            ),
          ),
          'button' => 
          array (
            'text' => 'View All Services',
            'route' => 'services',
          ),
        ),
        'working' => 
        array (
          'label' => 'Our Way of Working',
          'title' => 'First we understand.<br>Then we build.',
          'intro' => 'A clear process keeps business, management, and technical teams aligned from the beginning.',
          'items' => 
          array (
            0 => 
            array (
              'num' => '1',
              'title' => 'Listen',
              'text' => 'We sit with you and understand the real problem.',
            ),
            1 => 
            array (
              'num' => '2',
              'title' => 'Map',
              'text' => 'We document the process, users, data, and pain points.',
            ),
            2 => 
            array (
              'num' => '3',
              'title' => 'Plan',
              'text' => 'We define scope, priority, timeline, and responsibilities.',
            ),
            3 => 
            array (
              'num' => '4',
              'title' => 'Build',
              'text' => 'We design, develop, configure, or guide the solution.',
            ),
            4 => 
            array (
              'num' => '5',
              'title' => 'Support',
              'text' => 'We help the team use it, improve it, and continue with confidence.',
            ),
          ),
        ),
        'testimonials' => 
        array (
          'is_active' => true,
          'label' => 'Client Words',
          'title' => 'People remember clear work.',
          'lead' => 'A calm slider with enough time to read. Autoplay pauses on hover, focus, and touch.',
        ),
        'works_preview' => 
        array (
          'label' => 'Works',
          'title' => 'A few problems we helped solve.',
          'button' => 
          array (
            'text' => 'View Our Works',
            'route' => 'works',
          ),
        ),
        'values' => 
        array (
          'is_active' => true,
          'label' => 'How We Think',
          'title' => 'Principles that shape the work.',
          'lead' => 'The number follows the principle currently in view.',
          'items' => 
          array (
            0 => 
            array (
              'num' => '01',
              'mini' => '01 / clarity before execution',
              'title' => 'We do not start with software. We start with the work.',
              'text' => 'Understanding the real process prevents the team from building the wrong solution faster.',
              'example' => 'Example: A process and reporting fix may solve the problem before a large system is considered.',
            ),
            1 => 
            array (
              'num' => '02',
              'mini' => '02 / keep it practical',
              'title' => 'Simple where simple works.',
              'text' => 'Not every problem needs a complex platform. The right answer may be a clearer responsibility, a better form, or one useful dashboard.',
              'example' => 'Example: One well-designed approval flow can remove weeks of repeated follow-up.',
            ),
            2 => 
            array (
              'num' => '03',
              'mini' => '03 / fit the business',
              'title' => 'Technology is useful only when people can use it in real work.',
              'text' => 'We consider users, habits, data, controls, adoption, and the way the operation actually runs.',
              'example' => 'Example: A technically correct ERP still fails when the user journey does not match daily operations.',
            ),
            3 => 
            array (
              'num' => '04',
              'mini' => '04 / honest advice',
              'title' => 'We say what is needed, and what is not.',
              'text' => 'Clear advice protects the client’s time, budget, and attention. We do not add scope only to make the project bigger.',
              'example' => 'Example: Sometimes the right recommendation is to improve the current system rather than replace it.',
            ),
          ),
        ),
        'cta' => 
        array (
          'is_active' => true,
          'eyebrow' => 'Start with a conversation',
          'title' => 'Have a business problem that needs clear thinking?',
          'text' => 'Let’s talk first. No pressure. No hard selling. We will understand your situation, help organize the problem, and suggest a practical next step.',
          'button' => 
          array (
            'text' => 'Start a Conversation',
            'route' => NULL,
            'url' => 'https://wa.me/8801742110660',
          ),
          'save_button_text' => 'Save Contact',
          'qr_image_url' => '/images/default-itqan-contact-qr.png',
          'qr_alt' => 'ITQAN Consulting digital contact QR code',
          'qr_caption' => 'Scan to save the digital contact card directly to your phone.',
          'contact_file_name' => 'ITQAN-Consulting-Digital-Card.vcf',
          'vcard' => 
          array (
            'first_name' => 'Md Aminul',
            'last_name' => 'Islam',
            'full_name' => 'Md Aminul Islam, PMP, CSM',
            'credentials' => 'PMP, CSM',
            'organization' => 'ITQAN Consulting',
            'job_title' => 'Founder & Chief Consultant',
            'phone' => '+8801742110660',
            'whatsapp' => '+8801742110660',
            'email' => 'aminul@itqanconsulting.com',
            'website' => 'https://itqanconsulting.com',
            'note' => 'ITQAN Consulting provides business consulting, project and product management, software and web development, ERP and automation, UI/UX design, training, coaching, and dedicated team support. Remote team in Bangladesh. Serving international clients.',
          ),
        ),
      ),
      'about' => 
      array (
        'title' => 'About ITQAN Consulting',
        'meta_description' => 'A consulting-led technology partner built around real business needs.',
        'hero' => 
        array (
          'label' => 'About ITQAN',
          'title' => 'A consulting-led technology partner built around real business needs.',
          'description' => 'ITQAN Consulting helps businesses understand their work, improve their process, and use technology where it truly helps.',
          'buttons' => 
          array (
            0 => 
            array (
              'text' => 'Talk to Us',
              'route' => 'contact',
              'class' => 'blue',
            ),
          ),
        ),
        'story' => 
        array (
          'label' => 'Our Story',
          'title' => 'We do not start with software. We start with the work.',
          'paragraphs' => 
          array (
            0 => 'Many organizations have hardworking people, but the process is unclear. Reports come late. Requirements change without control. Software is requested before the real problem is understood.',
            1 => 'ITQAN was built to help in these moments. We listen, document, guide, and execute. The goal is not to make things bigger. The goal is to make work easier to understand and easier to manage.',
          ),
        ),
        'beliefs' => 
        array (
          'label' => 'What We Believe',
          'title' => 'Clear thinking is part of the delivery.',
          'items' => 
          array (
            0 => 
            array (
              'num' => '01',
              'title' => 'Clarity before execution',
              'text' => 'Scope must be understood before work starts.',
            ),
            1 => 
            array (
              'num' => '02',
              'title' => 'Simple where simple works',
              'text' => 'Not every problem needs a large system.',
            ),
            2 => 
            array (
              'num' => '03',
              'title' => 'Fit the real business',
              'text' => 'Tools should match how people actually work.',
            ),
            3 => 
            array (
              'num' => '04',
              'title' => 'Honest advice',
              'text' => 'We say what is useful, even when a smaller fix is enough.',
            ),
          ),
        ),
        'mission_vision' => 
        array (
          0 => 
          array (
            'num' => 'Mission',
            'title' => 'To make business work clearer, smarter, and easier to manage.',
            'text' => 'We focus on clear documents, useful systems, better reports, better coordination, and better control.',
          ),
          1 => 
          array (
            'num' => 'Vision',
            'title' => 'To become a trusted consulting and technology partner for growing businesses.',
            'text' => 'We want ITQAN to be known for sincerity, clarity, and useful delivery in Bangladesh and beyond.',
          ),
        ),
        'cta' => 
        array (
          'title' => 'Need a practical partner for your next system or project?',
          'text' => 'Share where the work feels stuck. We will help organize the next step.',
          'button' => 
          array (
            'text' => 'Book a Consultation',
            'route' => 'contact',
          ),
        ),
      ),
      'services' => 
      array (
        'title' => 'Services | ITQAN Consulting',
        'meta_description' => 'Services for businesses that need clarity, systems, and reliable execution.',
        'hero' => 
        array (
          'label' => 'Services',
          'title' => 'Services for businesses that need clarity, systems, and reliable execution.',
          'description' => 'From business analysis to software delivery, ITQAN supports the full journey.',
          'buttons' => 
          array (
            0 => 
            array (
              'text' => 'Start a Conversation',
              'route' => 'contact',
              'class' => 'blue',
            ),
            1 => 
            array (
              'text' => 'View Service Areas',
              'url' => '#service-areas',
              'class' => '',
            ),
          ),
        ),
        'faq_title' => 'Common Questions',
        'cta' => 
        array (
          'title' => 'Not sure which service you need?',
          'text' => 'Bring the problem. We will help organize the right scope.',
          'button' => 
          array (
            'text' => 'Start a Conversation',
            'route' => 'contact',
          ),
        ),
      ),
      'works' => 
      array (
        'title' => 'Works | ITQAN Consulting',
        'meta_description' => 'A few problems ITQAN helped solve.',
        'hero' => 
        array (
          'label' => 'Works',
          'title' => 'A few problems we helped solve.',
          'description' => 'Our work is not only about screens. It is about making business operations easier to see, manage, and improve.',
          'buttons' => 
          array (
            0 => 
            array (
              'text' => 'Discuss Your Project',
              'route' => 'contact',
              'class' => 'blue',
            ),
          ),
        ),
      ),
      'catalog' => 
      array (
        'title' => 'Digital Catalog | ITQAN Consulting',
        'meta_description' => 'Read the ITQAN Digital Catalog.',
        'hero' => 
        array (
          'label' => 'Digital Catalog',
          'title' => 'Read the ITQAN Digital Catalog.',
          'description' => 'Browse our consulting, technology, and delivery services in a smooth page-by-page format.',
          'buttons' => 
          array (
            0 => 
            array (
              'text' => 'Open Catalog',
              'url' => '#catalog-viewer',
              'class' => 'blue',
            ),
          ),
        ),
      ),
      'contact' => 
      array (
        'title' => 'Contact | ITQAN Consulting',
        'meta_description' => 'Let’s talk about what you are trying to fix.',
        'hero' => 
        array (
          'label' => 'Contact',
          'title' => 'Let’s talk about what you are trying to fix.',
          'description' => 'You do not need a perfect brief before contacting us. Share what is happening in your business. We will help you organize the problem.',
        ),
        'form' => 
        array (
          'is_active' => true,
          'label' => 'Start a conversation',
          'title' => 'Send the messy version. We will help organize it.',
          'intro' => 'No pressure. No hard selling. The form reveals one decision at a time so the first contact feels easier.',
          'steps' => 
          array (
            0 => 
            array (
              'title' => 'What feels unclear right now?',
              'text' => 'Select one or more. It does not need to be perfectly described.',
            ),
            1 => 
            array (
              'title' => 'What kind of support may help?',
              'text' => 'Choose what seems closest. ITQAN can help refine the scope later.',
            ),
            2 => 
            array (
              'title' => 'Share the basic details.',
              'text' => 'This helps us respond in a useful way.',
            ),
            3 => 
            array (
              'title' => 'Describe the situation in your own words.',
              'text' => 'It is okay if the information is incomplete.',
            ),
          ),
          'submit_text' => 'Send the messy version',
          'success_title' => 'Thank you. The first step is clear.',
          'success_text' => 'Your message has been received. ITQAN will contact you soon.',
        ),
        'cta' => 
        array (
          'is_active' => true,
          'eyebrow' => 'Save the contact',
          'title' => 'Keep ITQAN one scan away.',
          'text' => 'Scan the QR code to save the founder’s contact details directly to your phone.',
          'button' => 
          array (
            'text' => 'Start a Conversation',
            'route' => NULL,
            'url' => 'https://wa.me/8801742110660',
          ),
          'save_button_text' => 'Save Contact',
          'qr_image_url' => '/images/default-itqan-contact-qr.png',
          'qr_alt' => 'Scan to save ITQAN Consulting contact details',
          'qr_caption' => 'Scan to save the digital contact card.',
          'contact_file_name' => 'md-aminul-islam-itqan-consulting.vcf',
          'vcard' => 
          array (
            'first_name' => 'Md Aminul',
            'last_name' => 'Islam',
            'full_name' => 'Md Aminul Islam, PMP, CSM',
            'credentials' => 'PMP, CSM',
            'organization' => 'ITQAN Consulting',
            'job_title' => 'Founder & Chief Consultant',
            'phone' => '+8801742110660',
            'whatsapp' => '+8801742110660',
            'email' => 'aminul@itqanconsulting.com',
            'website' => 'https://itqanconsulting.com',
            'note' => 'ITQAN Consulting provides business consulting, project and product management, software and web development, ERP and automation, UI/UX design, training, coaching, and dedicated team support. Remote team in Bangladesh. Serving international clients.',
          ),
        ),
      ),
    ),
  ),
  'itqan_admin' => 
  array (
    'initial_admin' => 
    array (
      'name' => 'ITQAN Administrator',
      'email' => 'admin@itqanconsulting.com',
      'password' => 'AdminPassword@123',
    ),
  ),
  'itqan_contact' => 
  array (
    'recipient_email' => 'aminul@itqanconsulting.com',
    'captcha' => 
    array (
      'enabled' => true,
      'site_key' => '6Lfq2NctAAAAAMrhUXZvQHuB85ih7i4RbiM-u2HT',
      'secret_key' => '6Lfq2NctAAAAALIFa8ILrlJOXCfxThUa5UR32g3q',
      'verify_url' => 'https://www.google.com/recaptcha/api/siteverify',
      'timeout_seconds' => 5,
      'expected_hostname' => NULL,
    ),
  ),
  'itqan_security' => 
  array (
    'admin_session_timeout_minutes' => 30,
    'admin_login_max_attempts' => 5,
    'admin_login_decay_minutes' => 1,
    'admin_password_min_length' => 12,
  ),
  'logging' => 
  array (
    'default' => 'stack',
    'deprecations' => 
    array (
      'channel' => NULL,
      'trace' => false,
    ),
    'channels' => 
    array (
      'stack' => 
      array (
        'driver' => 'stack',
        'channels' => 
        array (
          0 => 'single',
        ),
        'ignore_exceptions' => false,
      ),
      'single' => 
      array (
        'driver' => 'single',
        'path' => '/Applications/XAMPP/xamppfiles/htdocs/laravel/ITQANConsulting/storage/logs/laravel.log',
        'level' => 'debug',
        'replace_placeholders' => true,
      ),
      'daily' => 
      array (
        'driver' => 'daily',
        'path' => '/Applications/XAMPP/xamppfiles/htdocs/laravel/ITQANConsulting/storage/logs/laravel.log',
        'level' => 'debug',
        'days' => 14,
        'replace_placeholders' => true,
      ),
      'slack' => 
      array (
        'driver' => 'slack',
        'url' => NULL,
        'username' => 'Laravel',
        'emoji' => ':boom:',
        'level' => 'debug',
        'replace_placeholders' => true,
      ),
      'papertrail' => 
      array (
        'driver' => 'monolog',
        'level' => 'debug',
        'handler' => 'Monolog\\Handler\\SyslogUdpHandler',
        'handler_with' => 
        array (
          'host' => NULL,
          'port' => NULL,
          'connectionString' => 'tls://:',
        ),
        'processors' => 
        array (
          0 => 'Monolog\\Processor\\PsrLogMessageProcessor',
        ),
      ),
      'stderr' => 
      array (
        'driver' => 'monolog',
        'level' => 'debug',
        'handler' => 'Monolog\\Handler\\StreamHandler',
        'handler_with' => 
        array (
          'stream' => 'php://stderr',
        ),
        'formatter' => NULL,
        'processors' => 
        array (
          0 => 'Monolog\\Processor\\PsrLogMessageProcessor',
        ),
      ),
      'syslog' => 
      array (
        'driver' => 'syslog',
        'level' => 'debug',
        'facility' => 8,
        'replace_placeholders' => true,
      ),
      'errorlog' => 
      array (
        'driver' => 'errorlog',
        'level' => 'debug',
        'replace_placeholders' => true,
      ),
      'null' => 
      array (
        'driver' => 'monolog',
        'handler' => 'Monolog\\Handler\\NullHandler',
      ),
      'emergency' => 
      array (
        'path' => '/Applications/XAMPP/xamppfiles/htdocs/laravel/ITQANConsulting/storage/logs/laravel.log',
      ),
    ),
  ),
  'mail' => 
  array (
    'default' => 'log',
    'mailers' => 
    array (
      'smtp' => 
      array (
        'transport' => 'smtp',
        'scheme' => NULL,
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '2525',
        'username' => NULL,
        'password' => NULL,
        'timeout' => NULL,
        'local_domain' => 'localhost',
      ),
      'ses' => 
      array (
        'transport' => 'ses',
      ),
      'postmark' => 
      array (
        'transport' => 'postmark',
      ),
      'resend' => 
      array (
        'transport' => 'resend',
      ),
      'sendmail' => 
      array (
        'transport' => 'sendmail',
        'path' => '/usr/sbin/sendmail -bs -i',
      ),
      'log' => 
      array (
        'transport' => 'log',
        'channel' => NULL,
      ),
      'array' => 
      array (
        'transport' => 'array',
      ),
      'failover' => 
      array (
        'transport' => 'failover',
        'mailers' => 
        array (
          0 => 'smtp',
          1 => 'log',
        ),
        'retry_after' => 60,
      ),
      'roundrobin' => 
      array (
        'transport' => 'roundrobin',
        'mailers' => 
        array (
          0 => 'ses',
          1 => 'postmark',
        ),
        'retry_after' => 60,
      ),
    ),
    'from' => 
    array (
      'address' => 'hello@example.com',
      'name' => 'Laravel',
    ),
    'markdown' => 
    array (
      'theme' => 'default',
      'paths' => 
      array (
        0 => '/Applications/XAMPP/xamppfiles/htdocs/laravel/ITQANConsulting/resources/views/vendor/mail',
      ),
      'extensions' => 
      array (
      ),
    ),
  ),
  'queue' => 
  array (
    'default' => 'database',
    'connections' => 
    array (
      'sync' => 
      array (
        'driver' => 'sync',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'connection' => NULL,
        'table' => 'jobs',
        'queue' => 'default',
        'retry_after' => 90,
        'after_commit' => false,
      ),
      'beanstalkd' => 
      array (
        'driver' => 'beanstalkd',
        'host' => 'localhost',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => 0,
        'after_commit' => false,
      ),
      'sqs' => 
      array (
        'driver' => 'sqs',
        'key' => '',
        'secret' => '',
        'prefix' => 'https://sqs.us-east-1.amazonaws.com/your-account-id',
        'queue' => 'default',
        'suffix' => NULL,
        'region' => 'us-east-1',
        'after_commit' => false,
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => NULL,
        'after_commit' => false,
      ),
      'deferred' => 
      array (
        'driver' => 'deferred',
      ),
      'failover' => 
      array (
        'driver' => 'failover',
        'connections' => 
        array (
          0 => 'database',
          1 => 'deferred',
        ),
      ),
      'background' => 
      array (
        'driver' => 'background',
      ),
    ),
    'batching' => 
    array (
      'database' => 'mysql',
      'table' => 'job_batches',
    ),
    'failed' => 
    array (
      'driver' => 'database-uuids',
      'database' => 'mysql',
      'table' => 'failed_jobs',
    ),
  ),
  'services' => 
  array (
    'postmark' => 
    array (
      'key' => NULL,
    ),
    'resend' => 
    array (
      'key' => NULL,
    ),
    'ses' => 
    array (
      'key' => '',
      'secret' => '',
      'region' => 'us-east-1',
    ),
    'slack' => 
    array (
      'notifications' => 
      array (
        'bot_user_oauth_token' => NULL,
        'channel' => NULL,
      ),
    ),
  ),
  'session' => 
  array (
    'driver' => 'database',
    'lifetime' => 120,
    'expire_on_close' => false,
    'encrypt' => false,
    'files' => '/Applications/XAMPP/xamppfiles/htdocs/laravel/ITQANConsulting/storage/framework/sessions',
    'connection' => NULL,
    'table' => 'sessions',
    'store' => NULL,
    'lottery' => 
    array (
      0 => 2,
      1 => 100,
    ),
    'cookie' => 'laravel-session',
    'path' => '/',
    'domain' => NULL,
    'secure' => NULL,
    'http_only' => true,
    'same_site' => 'lax',
    'partitioned' => false,
    'serialization' => 'json',
  ),
  'starpmaminul' => 
  array (
    'path' => 'starpmaminul',
    'database_connection' => 'starpmaminul',
    'admin' => 
    array (
      'name' => 'Portfolio Admin',
      'email' => 'admin@aminulislam.com',
      'password' => 'Admin@12345',
    ),
    'sections' => 
    array (
      'site' => 
      array (
        'label' => 'Site & Header',
        'description' => 'Page metadata, branding, navigation and the header call to action.',
        'icon' => 'layout',
        'defaults' => 
        array (
          'page_title' => 'Md Aminul Islam, PMP, CSM — Digital Resume',
          'loader_tagline' => 'Project · Product · ERP · PMO',
          'meta_description' => 'Md Aminul Islam, PMP, CSM — Project Delivery, ERP, PMO, Product and Digital Transformation Leader.',
          'brand_logo' => NULL,
          'brand_initials' => 'AMI',
          'brand_name' => 'Md Aminul Islam',
          'brand_credentials' => 'PMP® · CSM®',
          'navigation' => 
          array (
            0 => 
            array (
              'label' => 'About',
              'target' => '#about',
            ),
            1 => 
            array (
              'label' => 'Impact',
              'target' => '#impact',
            ),
            2 => 
            array (
              'label' => 'Work',
              'target' => '#work',
            ),
            3 => 
            array (
              'label' => 'Journey',
              'target' => '#journey',
            ),
            4 => 
            array (
              'label' => 'Voices',
              'target' => '#voices',
            ),
          ),
          'mobile_navigation' => 
          array (
            0 => 
            array (
              'label' => 'About',
              'target' => '#about',
            ),
            1 => 
            array (
              'label' => 'Impact',
              'target' => '#impact',
            ),
            2 => 
            array (
              'label' => 'Selected work',
              'target' => '#work',
            ),
            3 => 
            array (
              'label' => 'Career journey',
              'target' => '#journey',
            ),
            4 => 
            array (
              'label' => 'Testimonials',
              'target' => '#voices',
            ),
            5 => 
            array (
              'label' => 'Contact',
              'target' => '#contact',
            ),
          ),
          'header_cta_text' => 'Start a conversation',
          'header_cta_email' => 'aminul@itqanconsulting.com',
          'whatsapp_url' => 'https://wa.me/8801742110660?text=Hello%20Md%20Aminul%20Islam%2C%20I%20visited%20your%20digital%20resume%20and%20would%20like%20to%20discuss%20a%20project.',
          'whatsapp_label' => 'Chat with me on WhatsApp',
          'main_site_label' => 'Back to ITQAN Consulting',
        ),
        'fields' => 
        array (
          0 => 
          array (
            'name' => 'page_title',
            'label' => 'Browser page title',
            'type' => 'text',
          ),
          1 => 
          array (
            'name' => 'loader_tagline',
            'label' => 'Loading screen tagline',
            'type' => 'text',
          ),
          2 => 
          array (
            'name' => 'meta_description',
            'label' => 'Meta description',
            'type' => 'textarea',
            'rows' => 3,
          ),
          3 => 
          array (
            'name' => 'brand_logo',
            'label' => 'Complete header logo',
            'type' => 'image',
            'help' => 'Upload one complete logo image containing the mark, name and credentials. Recommended: transparent PNG or WebP with a wide horizontal layout.',
            'remove_label' => 'Remove the uploaded logo and use the AMI, name and credentials fallback.',
          ),
          4 => 
          array (
            'name' => 'brand_initials',
            'label' => 'Brand initials',
            'type' => 'text',
          ),
          5 => 
          array (
            'name' => 'brand_name',
            'label' => 'Brand name',
            'type' => 'text',
          ),
          6 => 
          array (
            'name' => 'brand_credentials',
            'label' => 'Brand credentials',
            'type' => 'text',
          ),
          7 => 
          array (
            'name' => 'navigation',
            'label' => 'Header navigation',
            'type' => 'collection',
            'fields' => 
            array (
              0 => 
              array (
                'name' => 'label',
                'label' => 'Label',
                'type' => 'text',
              ),
              1 => 
              array (
                'name' => 'target',
                'label' => 'Section target',
                'type' => 'text',
                'rules' => 
                array (
                  0 => 'starts_with:#',
                ),
                'help' => 'Keep the existing #section format.',
              ),
            ),
          ),
          8 => 
          array (
            'name' => 'mobile_navigation',
            'label' => 'Mobile navigation',
            'type' => 'collection',
            'fields' => 
            array (
              0 => 
              array (
                'name' => 'label',
                'label' => 'Label',
                'type' => 'text',
              ),
              1 => 
              array (
                'name' => 'target',
                'label' => 'Section target',
                'type' => 'text',
                'rules' => 
                array (
                  0 => 'starts_with:#',
                ),
              ),
            ),
          ),
          9 => 
          array (
            'name' => 'header_cta_text',
            'label' => 'Header button text',
            'type' => 'text',
          ),
          10 => 
          array (
            'name' => 'header_cta_email',
            'label' => 'Header contact email',
            'type' => 'email',
          ),
          11 => 
          array (
            'name' => 'whatsapp_url',
            'label' => 'Floating WhatsApp URL',
            'type' => 'url',
            'help' => 'Use a wa.me link with the country code and an optional prefilled message.',
          ),
          12 => 
          array (
            'name' => 'whatsapp_label',
            'label' => 'WhatsApp button accessible label',
            'type' => 'text',
          ),
          13 => 
          array (
            'name' => 'main_site_label',
            'label' => 'Back to ITQAN button accessible label',
            'type' => 'text',
          ),
        ),
      ),
      'hero' => 
      array (
        'label' => 'Hero',
        'description' => 'Opening message, profile details, portrait and key headline statistics.',
        'icon' => 'sparkles',
        'defaults' => 
        array (
          'availability' => 'Available for selected consulting and leadership engagements',
          'name_line_one' => 'Md Aminul',
          'name_line_two' => 'Islam.',
          'role_label' => 'What I do',
          'role_primary' => 'Project delivery and digital transformation leader.',
          'role_secondary' => 'I bring structure to ERP, PMO, product, fintech and complex technology programs.',
          'primary_button' => 'Explore selected work',
          'secondary_button' => 'Download resume',
          'resume_file' => NULL,
          'portrait' => NULL,
          'portrait_alt' => 'Professional portrait of Md Aminul Islam',
          'profile_name' => 'Md Aminul Islam, PMP®, CSM®',
          'profile_role' => 'Founder & Managing Consultant, ITQAN Consulting',
          'profile_number' => '01 / PROFILE',
          'stats' => 
          array (
            0 => 
            array (
              'value' => '15+',
              'label' => 'Years in delivery',
            ),
            1 => 
            array (
              'value' => '90K+',
              'label' => 'Users impacted',
            ),
            2 => 
            array (
              'value' => '38',
              'label' => 'Concurrent projects',
            ),
          ),
          'scroll_text' => 'Scroll through the story',
          'location_text' => 'Dhaka, Bangladesh · Serving teams internationally',
        ),
        'fields' => 
        array (
          0 => 
          array (
            'name' => 'availability',
            'label' => 'Availability message',
            'type' => 'text',
          ),
          1 => 
          array (
            'name' => 'name_line_one',
            'label' => 'Name — first line',
            'type' => 'text',
          ),
          2 => 
          array (
            'name' => 'name_line_two',
            'label' => 'Name — outlined line',
            'type' => 'text',
          ),
          3 => 
          array (
            'name' => 'role_label',
            'label' => 'Role label',
            'type' => 'text',
          ),
          4 => 
          array (
            'name' => 'role_primary',
            'label' => 'Primary role statement',
            'type' => 'text',
          ),
          5 => 
          array (
            'name' => 'role_secondary',
            'label' => 'Supporting role statement',
            'type' => 'textarea',
            'rows' => 3,
          ),
          6 => 
          array (
            'name' => 'primary_button',
            'label' => 'Primary button text',
            'type' => 'text',
          ),
          7 => 
          array (
            'name' => 'secondary_button',
            'label' => 'Download button text',
            'type' => 'text',
          ),
          8 => 
          array (
            'name' => 'resume_file',
            'label' => 'Resume / CV file',
            'type' => 'file',
            'accept' => 'application/pdf,.pdf,.doc,.docx',
            'mimes' => 
            array (
              0 => 'pdf',
              1 => 'doc',
              2 => 'docx',
            ),
            'max_kb' => 10240,
            'help' => 'Upload the final resume file. PDF is recommended. The public button downloads this file directly.',
            'remove_label' => 'Remove the uploaded resume and hide the public download button.',
          ),
          9 => 
          array (
            'name' => 'portrait',
            'label' => 'Professional portrait',
            'type' => 'image',
            'help' => 'Recommended: high-resolution vertical portrait. Leave empty to keep the template illustration.',
          ),
          10 => 
          array (
            'name' => 'portrait_alt',
            'label' => 'Portrait alternative text',
            'type' => 'text',
          ),
          11 => 
          array (
            'name' => 'profile_name',
            'label' => 'Portrait nameplate',
            'type' => 'text',
          ),
          12 => 
          array (
            'name' => 'profile_role',
            'label' => 'Portrait role',
            'type' => 'text',
          ),
          13 => 
          array (
            'name' => 'profile_number',
            'label' => 'Portrait index',
            'type' => 'text',
          ),
          14 => 
          array (
            'name' => 'stats',
            'label' => 'Floating statistics',
            'type' => 'collection',
            'fields' => 
            array (
              0 => 
              array (
                'name' => 'value',
                'label' => 'Value',
                'type' => 'text',
              ),
              1 => 
              array (
                'name' => 'label',
                'label' => 'Label',
                'type' => 'text',
              ),
            ),
          ),
          15 => 
          array (
            'name' => 'scroll_text',
            'label' => 'Scroll cue',
            'type' => 'text',
          ),
          16 => 
          array (
            'name' => 'location_text',
            'label' => 'Location line',
            'type' => 'text',
          ),
        ),
      ),
      'ticker' => 
      array (
        'label' => 'Expertise Ticker',
        'description' => 'The continuously scrolling expertise labels below the hero.',
        'icon' => 'repeat',
        'defaults' => 
        array (
          'items' => 
          array (
            0 => 
            array (
              'label' => 'Project & Portfolio Delivery',
            ),
            1 => 
            array (
              'label' => 'ERP Implementation',
            ),
            2 => 
            array (
              'label' => 'PMO Governance',
            ),
            3 => 
            array (
              'label' => 'Product Delivery',
            ),
            4 => 
            array (
              'label' => 'Fintech & Microfinance Systems',
            ),
            5 => 
            array (
              'label' => 'Business Analysis',
            ),
            6 => 
            array (
              'label' => 'Team Development',
            ),
          ),
        ),
        'fields' => 
        array (
          0 => 
          array (
            'name' => 'items',
            'label' => 'Ticker items',
            'type' => 'collection',
            'fields' => 
            array (
              0 => 
              array (
                'name' => 'label',
                'label' => 'Item text',
                'type' => 'text',
              ),
            ),
          ),
        ),
      ),
      'philosophy' => 
      array (
        'label' => 'Leadership Philosophy',
        'description' => 'The philosophy statement, manifesto and animated leadership-value orbit.',
        'icon' => 'compass',
        'defaults' => 
        array (
          'section_index' => '01 · Leadership philosophy',
          'title_prefix' => 'Every role is an',
          'title_emphasis' => 'Amanah.',
          'description' => 'I try to lead with sincerity, fairness and ownership. The work must be useful. The process must be honest. And people should become stronger because we worked together.',
          'manifesto_mark' => '01',
          'manifesto_intro' => 'At the center is one commitment:',
          'manifesto_core' => 'Serve Well',
          'manifesto_body' => 'Around it are Ikhlās, Amanah, Adl and Ihsān—so the work is useful, responsible, fair and excellent; and, in shā’ Allāh, pleasing to Allah SWT.',
          'orbit_text' => 'SINCERITY · TRUST · FAIRNESS · EXCELLENCE · SERVICE · RESPONSIBILITY ·',
          'center_label' => 'Centered on',
          'center_line_one' => 'Serve',
          'center_line_two' => 'Well',
          'center_caption_line_one' => 'Useful work.',
          'center_caption_line_two' => 'Honest process.',
          'interaction_caption' => 'Move to explore',
          'values' => 
          array (
            0 => 
            array (
              'name' => 'Ikhlās',
              'meaning' => 'Sincerity',
              'detail' => 'Pure intention',
            ),
            1 => 
            array (
              'name' => 'Amanah',
              'meaning' => 'Trust',
              'detail' => 'Owned responsibly',
            ),
            2 => 
            array (
              'name' => 'Adl',
              'meaning' => 'Fairness',
              'detail' => 'Balanced judgment',
            ),
            3 => 
            array (
              'name' => 'Ihsān',
              'meaning' => 'Excellence',
              'detail' => 'Better than required',
            ),
          ),
        ),
        'fields' => 
        array (
          0 => 
          array (
            'name' => 'section_index',
            'label' => 'Section label',
            'type' => 'text',
          ),
          1 => 
          array (
            'name' => 'title_prefix',
            'label' => 'Title',
            'type' => 'text',
          ),
          2 => 
          array (
            'name' => 'title_emphasis',
            'label' => 'Emphasized title word',
            'type' => 'text',
          ),
          3 => 
          array (
            'name' => 'description',
            'label' => 'Description',
            'type' => 'textarea',
            'rows' => 4,
          ),
          4 => 
          array (
            'name' => 'manifesto_mark',
            'label' => 'Manifesto number',
            'type' => 'text',
          ),
          5 => 
          array (
            'name' => 'manifesto_intro',
            'label' => 'Manifesto opening',
            'type' => 'text',
          ),
          6 => 
          array (
            'name' => 'manifesto_core',
            'label' => 'Manifesto highlighted commitment',
            'type' => 'text',
          ),
          7 => 
          array (
            'name' => 'manifesto_body',
            'label' => 'Manifesto supporting text',
            'type' => 'textarea',
            'rows' => 4,
          ),
          8 => 
          array (
            'name' => 'orbit_text',
            'label' => 'Orbit text',
            'type' => 'text',
            'help' => 'Use short uppercase words separated by dots for the circular label.',
          ),
          9 => 
          array (
            'name' => 'center_label',
            'label' => 'Center label',
            'type' => 'text',
          ),
          10 => 
          array (
            'name' => 'center_line_one',
            'label' => 'Center text — first line',
            'type' => 'text',
          ),
          11 => 
          array (
            'name' => 'center_line_two',
            'label' => 'Center text — second line',
            'type' => 'text',
          ),
          12 => 
          array (
            'name' => 'center_caption_line_one',
            'label' => 'Center caption — first line',
            'type' => 'text',
          ),
          13 => 
          array (
            'name' => 'center_caption_line_two',
            'label' => 'Center caption — second line',
            'type' => 'text',
          ),
          14 => 
          array (
            'name' => 'interaction_caption',
            'label' => 'Interaction hint',
            'type' => 'text',
          ),
          15 => 
          array (
            'name' => 'values',
            'label' => 'Leadership values',
            'type' => 'collection',
            'fields' => 
            array (
              0 => 
              array (
                'name' => 'name',
                'label' => 'Value',
                'type' => 'text',
              ),
              1 => 
              array (
                'name' => 'meaning',
                'label' => 'Meaning',
                'type' => 'text',
              ),
              2 => 
              array (
                'name' => 'detail',
                'label' => 'Hover detail',
                'type' => 'text',
              ),
            ),
          ),
        ),
      ),
      'overview' => 
      array (
        'label' => 'Professional Overview',
        'description' => 'Professional summary and core capability list.',
        'icon' => 'list',
        'defaults' => 
        array (
          'section_index' => '02 · Professional overview',
          'title' => 'I turn complexity into controlled delivery.',
          'description' => 'Organizations rarely struggle because people are not trying. More often, priorities are unclear, ownership overlaps, requirements keep moving, and leaders cannot see what is really happening. That is where I work best.',
          'capabilities' => 
          array (
            0 => 
            array (
              'title' => 'Project, program & portfolio delivery',
              'description' => 'Planning, governance, risk control, stakeholder alignment and execution across complex technology portfolios.',
            ),
            1 => 
            array (
              'title' => 'ERP & enterprise transformation',
              'description' => 'Business-process alignment, requirements, phased rollout, data migration, adoption and cross-functional coordination.',
            ),
            2 => 
            array (
              'title' => 'PMO setup & project recovery',
              'description' => 'Practical reporting, delivery standards, dashboards, budget controls and intervention for delayed or unclear projects.',
            ),
            3 => 
            array (
              'title' => 'Product & digital platform delivery',
              'description' => 'Turning business needs into roadmaps, structured requirements, priorities, release plans and usable digital experiences.',
            ),
            4 => 
            array (
              'title' => 'Fintech & microfinance systems',
              'description' => 'Experience connecting finance, operations, user workflows and technology across microfinance, banking and payment-related platforms.',
            ),
          ),
        ),
        'fields' => 
        array (
          0 => 
          array (
            'name' => 'section_index',
            'label' => 'Section label',
            'type' => 'text',
          ),
          1 => 
          array (
            'name' => 'title',
            'label' => 'Title',
            'type' => 'text',
          ),
          2 => 
          array (
            'name' => 'description',
            'label' => 'Introduction',
            'type' => 'textarea',
            'rows' => 5,
          ),
          3 => 
          array (
            'name' => 'capabilities',
            'label' => 'Capabilities',
            'type' => 'collection',
            'fields' => 
            array (
              0 => 
              array (
                'name' => 'title',
                'label' => 'Capability title',
                'type' => 'text',
              ),
              1 => 
              array (
                'name' => 'description',
                'label' => 'Capability description',
                'type' => 'textarea',
                'rows' => 3,
              ),
            ),
          ),
        ),
      ),
      'impact' => 
      array (
        'label' => 'Scale & Impact',
        'description' => 'Section introduction and animated metric cards.',
        'icon' => 'chart',
        'defaults' => 
        array (
          'section_index' => '03 · Scale & impact',
          'title' => 'A career measured in delivery, not job titles.',
          'description' => 'From nationwide ERP rollout to PMO leadership and digital products, the common thread has been simple: make work visible, align people, reduce confusion and deliver responsibly.',
          'metrics' => 
          array (
            0 => 
            array (
              'prefix' => '',
              'value' => '15',
              'suffix' => '+',
              'decimals' => '0',
              'description' => 'Years across technology, finance, manufacturing, project delivery and consulting.',
            ),
            1 => 
            array (
              'prefix' => '',
              'value' => '90',
              'suffix' => 'K+',
              'decimals' => '0',
              'description' => 'Users served by the enterprise ERP program delivered for BRAC operations.',
            ),
            2 => 
            array (
              'prefix' => '',
              'value' => '3200',
              'suffix' => '+',
              'decimals' => '0',
              'description' => 'Branches and operational locations reached through large-scale rollout.',
            ),
            3 => 
            array (
              'prefix' => '',
              'value' => '3000',
              'suffix' => '+',
              'decimals' => '0',
              'description' => 'Transactions per second supported by the high-volume enterprise platform.',
            ),
            4 => 
            array (
              'prefix' => '',
              'value' => '38',
              'suffix' => '',
              'decimals' => '0',
              'description' => 'Concurrent projects managed within a diverse portfolio of large, medium and small initiatives.',
            ),
            5 => 
            array (
              'prefix' => '$',
              'value' => '9.14',
              'suffix' => 'M',
              'decimals' => '2',
              'description' => 'Approximate value of the flagship enterprise ERP implementation program.',
            ),
            6 => 
            array (
              'prefix' => '$',
              'value' => '639',
              'suffix' => 'K+',
              'decimals' => '0',
              'description' => 'Cost efficiency identified through the BRAC University SAP audit engagement.',
            ),
            7 => 
            array (
              'prefix' => '',
              'value' => '300',
              'suffix' => '+',
              'decimals' => '0',
              'description' => 'Professionals trained or mentored in project management, Agile, BA and leadership.',
            ),
          ),
        ),
        'fields' => 
        array (
          0 => 
          array (
            'name' => 'section_index',
            'label' => 'Section label',
            'type' => 'text',
          ),
          1 => 
          array (
            'name' => 'title',
            'label' => 'Title',
            'type' => 'text',
          ),
          2 => 
          array (
            'name' => 'description',
            'label' => 'Introduction',
            'type' => 'textarea',
            'rows' => 4,
          ),
          3 => 
          array (
            'name' => 'metrics',
            'label' => 'Impact metrics',
            'type' => 'collection',
            'fields' => 
            array (
              0 => 
              array (
                'name' => 'prefix',
                'label' => 'Prefix',
                'type' => 'text',
                'placeholder' => '$',
              ),
              1 => 
              array (
                'name' => 'value',
                'label' => 'Number',
                'type' => 'number',
                'step' => 'any',
              ),
              2 => 
              array (
                'name' => 'suffix',
                'label' => 'Suffix',
                'type' => 'text',
                'placeholder' => 'K+',
              ),
              3 => 
              array (
                'name' => 'decimals',
                'label' => 'Decimal places',
                'type' => 'number',
                'step' => '1',
                'rules' => 
                array (
                  0 => 'integer',
                  1 => 'min:0',
                  2 => 'max:4',
                ),
              ),
              4 => 
              array (
                'name' => 'description',
                'label' => 'Description',
                'type' => 'textarea',
                'rows' => 3,
              ),
            ),
          ),
        ),
      ),
      'work' => 
      array (
        'label' => 'Selected Work',
        'description' => 'Selected project cards and their slide-out project details.',
        'icon' => 'briefcase',
        'defaults' => 
        array (
          'section_index' => '04 · Selected work',
          'title' => 'Work that changed how organizations operate.',
          'description' => 'A focused selection from enterprise systems, PMO transformation, digital platforms, audits and international operations.',
          'drawer_placeholder_label' => 'Selected engagement',
          'drawer_placeholder_title' => 'Project title',
          'drawer_placeholder_description' => 'Project description.',
          'projects' => 
          array (
            0 => 
            array (
              'key' => 'brac',
              'label' => 'Flagship program · ERP',
              'title' => 'BRAC ERP',
              'summary' => 'A multi-module enterprise platform supporting nationwide microfinance and core operations at exceptional scale.',
              'tags' => '90,000+ users|3,200+ branches|11 modules|3,000+ TPS',
              'drawer_label' => 'Flagship program · Enterprise ERP',
              'drawer_intro' => 'A multi-year transformation program supporting microfinance, finance, HR, inventory and other critical operations across a nationwide network.',
              'details' => 
              array (
                0 => 
                array (
                  'label' => 'Role',
                  'text' => 'Project Manager → PMO leadership. Joined as the first dedicated Project Manager for the ERP program and helped scale the project-management function.',
                ),
                1 => 
                array (
                  'label' => 'Scale',
                  'text' => '90,000+ users, 3,200+ branches, 11 modules and more than 3,000 transactions per second.',
                ),
                2 => 
                array (
                  'label' => 'Contribution',
                  'text' => 'Program planning, stakeholder coordination, risk and issue management, business analysis support, phased rollout, data validation and governance.',
                ),
                3 => 
                array (
                  'label' => 'Outcome',
                  'text' => 'Stronger delivery visibility, improved coordination between business and technology teams, and controlled rollout with reduced operational disruption.',
                ),
              ),
            ),
            1 => 
            array (
              'key' => 'cartup',
              'label' => 'E-commerce · Product delivery',
              'title' => 'CartUp.com',
              'summary' => 'PMO governance, product lifecycle support, Agile delivery and release coordination for a major e-commerce platform.',
              'tags' => 'PMO setup|Product releases|Agile',
              'drawer_label' => 'E-commerce · Product and delivery',
              'drawer_intro' => 'PMO and product-delivery support for an e-commerce platform within US-Bangla Group.',
              'details' => 
              array (
                0 => 
                array (
                  'label' => 'Role',
                  'text' => 'Head of PMO, supporting governance, team mentoring, project risk, stakeholder communication and delivery standards.',
                ),
                1 => 
                array (
                  'label' => 'Product work',
                  'text' => 'Requirements, feature ideation, prioritization, release planning, campaign readiness, retrospectives and delivery improvement.',
                ),
                2 => 
                array (
                  'label' => 'Approach',
                  'text' => 'Connected business priorities, product decisions and technical execution through visible planning and regular coordination.',
                ),
              ),
            ),
            2 => 
            array (
              'key' => 'sap',
              'label' => 'Enterprise audit',
              'title' => 'SAP Audit',
              'summary' => 'System and implementation review for BRAC University that identified significant cost efficiency.',
              'tags' => '~$639K savings|Audit',
              'drawer_label' => 'Enterprise system review',
              'drawer_intro' => 'A structured review of the SAP engagement and implementation approach for BRAC University.',
              'details' => 
              array (
                0 => 
                array (
                  'label' => 'Focus',
                  'text' => 'Review of scope, implementation concerns, costs and practical fit.',
                ),
                1 => 
                array (
                  'label' => 'Impact',
                  'text' => 'The engagement identified approximately USD 639K in cost efficiency.',
                ),
                2 => 
                array (
                  'label' => 'Value',
                  'text' => 'Helped leadership make a better-informed enterprise-system decision.',
                ),
              ),
            ),
            3 => 
            array (
              'key' => 'pmo',
              'label' => 'Governance · CMMI',
              'title' => 'PMO Transformation',
              'summary' => 'JIRA-connected KPI visibility, delivery standards, budgeting discipline, reporting and CMMI Level III practices.',
              'tags' => '38 projects|12-member PMO',
              'drawer_label' => 'PMO · Governance · CMMI',
              'drawer_intro' => 'Building delivery systems that make projects easier to govern, understand and improve.',
              'details' => 
              array (
                0 => 
                array (
                  'label' => 'BRAC IT',
                  'text' => 'Managed a 38-project portfolio, introduced JIRA-connected dashboards, reporting, resource planning and delivery-development practices.',
                ),
                1 => 
                array (
                  'label' => 'Synesis IT',
                  'text' => 'Created a PMO charter, strengthened project budgeting, delivery KPIs and CMMI-aligned practices.',
                ),
                2 => 
                array (
                  'label' => 'TechnoNext',
                  'text' => 'Supported centralized PMO frameworks, Agile adoption, team mentoring and e-commerce delivery governance.',
                ),
                3 => 
                array (
                  'label' => 'Capability',
                  'text' => 'Led and developed project managers, program managers and coordinators across different organizational settings.',
                ),
              ),
            ),
            4 => 
            array (
              'key' => 'global',
              'label' => 'International operations',
              'title' => 'Across Borders',
              'summary' => 'ERP rollout in Africa and manufacturing automation work in China, connecting operations, inventory and technology teams.',
              'tags' => 'China|Sierra Leone|Liberia',
              'drawer_label' => 'International and cross-border work',
              'drawer_intro' => 'Delivery experience across different operational cultures and business environments.',
              'details' => 
              array (
                0 => 
                array (
                  'label' => 'China',
                  'text' => 'Business and manufacturing operations, including automation and inventory-related solutions for custom-gift production serving international clients.',
                ),
                1 => 
                array (
                  'label' => 'Sierra Leone & Liberia',
                  'text' => 'Supported ERP rollout and stakeholder coordination in multi-country environments.',
                ),
                2 => 
                array (
                  'label' => 'Bangladesh',
                  'text' => 'Enterprise, government, NGO, education, financial-services and technology delivery.',
                ),
                3 => 
                array (
                  'label' => 'Lesson',
                  'text' => 'Technology works best when the delivery model respects local workflows, people and operational reality.',
                ),
              ),
            ),
          ),
        ),
        'fields' => 
        array (
          0 => 
          array (
            'name' => 'section_index',
            'label' => 'Section label',
            'type' => 'text',
          ),
          1 => 
          array (
            'name' => 'title',
            'label' => 'Title',
            'type' => 'text',
          ),
          2 => 
          array (
            'name' => 'description',
            'label' => 'Introduction',
            'type' => 'textarea',
            'rows' => 4,
          ),
          3 => 
          array (
            'name' => 'drawer_placeholder_label',
            'label' => 'Project drawer placeholder label',
            'type' => 'text',
          ),
          4 => 
          array (
            'name' => 'drawer_placeholder_title',
            'label' => 'Project drawer placeholder title',
            'type' => 'text',
          ),
          5 => 
          array (
            'name' => 'drawer_placeholder_description',
            'label' => 'Project drawer placeholder description',
            'type' => 'text',
          ),
          6 => 
          array (
            'name' => 'projects',
            'label' => 'Project cards',
            'type' => 'collection',
            'fields' => 
            array (
              0 => 
              array (
                'name' => 'key',
                'label' => 'Internal key',
                'type' => 'text',
                'rules' => 
                array (
                  0 => 'alpha_dash',
                  1 => 'distinct',
                ),
                'help' => 'Keep unique. Used only for opening the project drawer.',
              ),
              1 => 
              array (
                'name' => 'label',
                'label' => 'Card label',
                'type' => 'text',
              ),
              2 => 
              array (
                'name' => 'title',
                'label' => 'Project title',
                'type' => 'text',
              ),
              3 => 
              array (
                'name' => 'summary',
                'label' => 'Card summary',
                'type' => 'textarea',
                'rows' => 3,
              ),
              4 => 
              array (
                'name' => 'tags',
                'label' => 'Card tags',
                'type' => 'text',
                'help' => 'Separate tags with |.',
              ),
              5 => 
              array (
                'name' => 'drawer_label',
                'label' => 'Drawer label',
                'type' => 'text',
              ),
              6 => 
              array (
                'name' => 'drawer_intro',
                'label' => 'Drawer introduction',
                'type' => 'textarea',
                'rows' => 3,
              ),
              7 => 
              array (
                'name' => 'details',
                'label' => 'Drawer details',
                'type' => 'collection',
                'fields' => 
                array (
                  0 => 
                  array (
                    'name' => 'label',
                    'label' => 'Detail label',
                    'type' => 'text',
                  ),
                  1 => 
                  array (
                    'name' => 'text',
                    'label' => 'Detail text',
                    'type' => 'textarea',
                    'rows' => 3,
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
      'case_study' => 
      array (
        'label' => 'Signature Case Study',
        'description' => 'Case study introduction, dashboard labels and delivery steps.',
        'icon' => 'file',
        'defaults' => 
        array (
          'section_index' => '05 · Signature case study',
          'title' => 'BRAC ERP. Nationwide scale, controlled one step at a time.',
          'description' => 'The program required far more than software delivery. It needed business understanding, structured decisions, phased execution, user validation and patient coordination across a large organization.',
          'dashboard_label' => 'Program delivery view · illustrative',
          'kpis' => 
          array (
            0 => 
            array (
              'value' => '90K+',
              'label' => 'Active users',
            ),
            1 => 
            array (
              'value' => '3.2K+',
              'label' => 'Branches',
            ),
            2 => 
            array (
              'value' => '11',
              'label' => 'ERP modules',
            ),
          ),
          'chart_title' => 'Illustrative rollout wave progression',
          'steps' => 
          array (
            0 => 
            array (
              'title' => 'Structure the delivery',
              'description' => 'Program-level reporting, regular reviews and clearer visibility across modules gave leadership a practical view of progress, risks and decisions.',
            ),
            1 => 
            array (
              'title' => 'Align business and technology',
              'description' => 'Continuous engagement connected real branch workflows, enterprise requirements, technical feasibility and stakeholder expectations.',
            ),
            2 => 
            array (
              'title' => 'Prioritize and validate',
              'description' => 'Requirements were organized into phases, supported by demos, prototypes, user feedback, field insight and controlled acceptance.',
            ),
            3 => 
            array (
              'title' => 'Roll out in waves',
              'description' => 'Pilots, data validation, reconciliation and phased deployment reduced operational risk while the platform expanded nationwide.',
            ),
            4 => 
            array (
              'title' => 'Build capability around the system',
              'description' => 'The project management function grew from the first dedicated role into a broader PMO, embedding planning, risk, communication and governance practices.',
            ),
          ),
        ),
        'fields' => 
        array (
          0 => 
          array (
            'name' => 'section_index',
            'label' => 'Section label',
            'type' => 'text',
          ),
          1 => 
          array (
            'name' => 'title',
            'label' => 'Title',
            'type' => 'text',
          ),
          2 => 
          array (
            'name' => 'description',
            'label' => 'Introduction',
            'type' => 'textarea',
            'rows' => 5,
          ),
          3 => 
          array (
            'name' => 'dashboard_label',
            'label' => 'Dashboard label',
            'type' => 'text',
          ),
          4 => 
          array (
            'name' => 'kpis',
            'label' => 'Dashboard KPIs',
            'type' => 'collection',
            'fields' => 
            array (
              0 => 
              array (
                'name' => 'value',
                'label' => 'Value',
                'type' => 'text',
              ),
              1 => 
              array (
                'name' => 'label',
                'label' => 'Label',
                'type' => 'text',
              ),
            ),
          ),
          5 => 
          array (
            'name' => 'chart_title',
            'label' => 'Chart caption',
            'type' => 'text',
          ),
          6 => 
          array (
            'name' => 'steps',
            'label' => 'Case study steps',
            'type' => 'collection',
            'fields' => 
            array (
              0 => 
              array (
                'name' => 'title',
                'label' => 'Step title',
                'type' => 'text',
              ),
              1 => 
              array (
                'name' => 'description',
                'label' => 'Step description',
                'type' => 'textarea',
                'rows' => 3,
              ),
            ),
          ),
        ),
      ),
      'journey' => 
      array (
        'label' => 'Career Journey',
        'description' => 'Career timeline introduction and timeline entries.',
        'icon' => 'route',
        'defaults' => 
        array (
          'section_index' => '06 · Career journey',
          'title' => 'Built from operations. Grown through delivery. Now focused on advisory and impact.',
          'description' => 'The titles changed. The core work stayed familiar: understand the problem, organize people and decisions, then see the work through.',
          'items' => 
          array (
            0 => 
            array (
              'period' => '2025 — Now',
              'role' => 'Founder & Managing Consultant',
              'company' => 'ITQAN Consulting',
              'intro' => 'Helping organizations with',
              'highlight' => 'project delivery, ERP, PMO, business analysis, product support, software planning, audit, recovery and capability development.',
            ),
            1 => 
            array (
              'period' => '2024 — 2025',
              'role' => 'Head of PMO',
              'company' => 'TechnoNext · US-Bangla Group',
              'intro' => 'Supported centralized PMO setup and worked closely with the',
              'highlight' => 'CartUp e-commerce product lifecycle, release planning, risk, governance and delivery improvement.',
            ),
            2 => 
            array (
              'period' => '2024',
              'role' => 'GM & Head of Project Management',
              'company' => 'Synesis IT PLC',
              'intro' => 'Led a team across strategic projects, introduced a PMO charter, project budgeting, delivery KPIs and',
              'highlight' => 'CMMI-aligned management practices.',
            ),
            3 => 
            array (
              'period' => '2017 — 2024',
              'role' => 'Acting Head of Project Management',
              'company' => 'BRAC IT',
              'intro' => 'Progressed through project leadership roles, managed a portfolio of 38 projects, helped deliver the flagship ERP and built',
              'highlight' => 'PMO, JIRA, CMMI and team-development practices.',
            ),
            4 => 
            array (
              'period' => 'Earlier',
              'role' => 'Business, BA & Project Foundations',
              'company' => 'China · Ergo Ventures · United Finance',
              'intro' => 'Early work across financial operations, business analysis, software projects, client management and manufacturing operations created a practical bridge between',
              'highlight' => 'business reality and technology delivery.',
            ),
          ),
        ),
        'fields' => 
        array (
          0 => 
          array (
            'name' => 'section_index',
            'label' => 'Section label',
            'type' => 'text',
          ),
          1 => 
          array (
            'name' => 'title',
            'label' => 'Title',
            'type' => 'text',
          ),
          2 => 
          array (
            'name' => 'description',
            'label' => 'Introduction',
            'type' => 'textarea',
            'rows' => 4,
          ),
          3 => 
          array (
            'name' => 'items',
            'label' => 'Timeline entries',
            'type' => 'collection',
            'fields' => 
            array (
              0 => 
              array (
                'name' => 'period',
                'label' => 'Period',
                'type' => 'text',
              ),
              1 => 
              array (
                'name' => 'role',
                'label' => 'Role',
                'type' => 'text',
              ),
              2 => 
              array (
                'name' => 'company',
                'label' => 'Company',
                'type' => 'text',
              ),
              3 => 
              array (
                'name' => 'intro',
                'label' => 'Description introduction',
                'type' => 'textarea',
                'rows' => 3,
              ),
              4 => 
              array (
                'name' => 'highlight',
                'label' => 'Bold closing text',
                'type' => 'textarea',
                'rows' => 3,
              ),
            ),
          ),
        ),
      ),
      'operating_system' => 
      array (
        'label' => 'How I Work',
        'description' => 'Operating principles and the four-step delivery approach.',
        'icon' => 'settings',
        'defaults' => 
        array (
          'section_index' => '07 · How I work',
          'title' => 'Clarity first. Then structure. Then disciplined execution.',
          'description' => 'I do not begin with a fixed answer. I begin by understanding the people, the process, the system and the result that actually matters.',
          'steps' => 
          array (
            0 => 
            array (
              'label' => '01 / Understand',
              'title' => 'Find the real problem.',
              'description' => 'Listen to users, management and delivery teams. Separate symptoms from root causes.',
            ),
            1 => 
            array (
              'label' => '02 / Structure',
              'title' => 'Make the work visible.',
              'description' => 'Define scope, ownership, priorities, risks, decisions, milestones and reporting.',
            ),
            2 => 
            array (
              'label' => '03 / Align',
              'title' => 'Bring people together.',
              'description' => 'Connect business, technology, vendors and leaders around the same practical plan.',
            ),
            3 => 
            array (
              'label' => '04 / Deliver',
              'title' => 'Execute, learn, improve.',
              'description' => 'Track outcomes, remove blockers, validate early and leave the organization stronger.',
            ),
          ),
        ),
        'fields' => 
        array (
          0 => 
          array (
            'name' => 'section_index',
            'label' => 'Section label',
            'type' => 'text',
          ),
          1 => 
          array (
            'name' => 'title',
            'label' => 'Title',
            'type' => 'text',
          ),
          2 => 
          array (
            'name' => 'description',
            'label' => 'Introduction',
            'type' => 'textarea',
            'rows' => 4,
          ),
          3 => 
          array (
            'name' => 'steps',
            'label' => 'Working method',
            'type' => 'collection',
            'fields' => 
            array (
              0 => 
              array (
                'name' => 'label',
                'label' => 'Step label',
                'type' => 'text',
              ),
              1 => 
              array (
                'name' => 'title',
                'label' => 'Step title',
                'type' => 'text',
              ),
              2 => 
              array (
                'name' => 'description',
                'label' => 'Step description',
                'type' => 'textarea',
                'rows' => 3,
              ),
            ),
          ),
        ),
      ),
      'global' => 
      array (
        'label' => 'Cross-Border Perspective',
        'description' => 'International experience introduction, country labels and map caption.',
        'icon' => 'globe',
        'defaults' => 
        array (
          'section_index' => '08 · Cross-border perspective',
          'title' => 'Local context. International exposure.',
          'description' => 'Experience across Bangladesh, China and African rollout environments taught me that systems only work when they respect how people really operate.',
          'countries' => 
          array (
            0 => 
            array (
              'name' => 'Bangladesh',
            ),
            1 => 
            array (
              'name' => 'China',
            ),
            2 => 
            array (
              'name' => 'Sierra Leone',
            ),
            3 => 
            array (
              'name' => 'Liberia',
            ),
            4 => 
            array (
              'name' => 'International remote work',
            ),
          ),
          'caption_title' => 'Business, technology and people do not speak separate languages.',
          'caption_description' => 'Strong delivery connects all three. That belief has shaped my work across enterprise, development, e-commerce, government and manufacturing environments.',
        ),
        'fields' => 
        array (
          0 => 
          array (
            'name' => 'section_index',
            'label' => 'Section label',
            'type' => 'text',
          ),
          1 => 
          array (
            'name' => 'title',
            'label' => 'Title',
            'type' => 'text',
          ),
          2 => 
          array (
            'name' => 'description',
            'label' => 'Introduction',
            'type' => 'textarea',
            'rows' => 4,
          ),
          3 => 
          array (
            'name' => 'countries',
            'label' => 'Country tags',
            'type' => 'collection',
            'fields' => 
            array (
              0 => 
              array (
                'name' => 'name',
                'label' => 'Country / location',
                'type' => 'text',
              ),
            ),
          ),
          4 => 
          array (
            'name' => 'caption_title',
            'label' => 'Map caption title',
            'type' => 'text',
          ),
          5 => 
          array (
            'name' => 'caption_description',
            'label' => 'Map caption description',
            'type' => 'textarea',
            'rows' => 3,
          ),
        ),
      ),
      'testimonials' => 
      array (
        'label' => 'Testimonials',
        'description' => 'Section title and testimonial slider content.',
        'icon' => 'quote',
        'defaults' => 
        array (
          'section_index' => '09 · What people say',
          'title' => 'Leadership is visible in the people around you.',
          'items' => 
          array (
            0 => 
            array (
              'quote' => 'Aminul Bhai isn’t just a leader — he’s the architect of careers.',
              'initials' => 'RN',
              'name' => 'Razit Nihal',
              'role' => 'Project Manager & Product Owner',
            ),
            1 => 
            array (
              'quote' => 'The best mentor I have had. His guidance shaped my professional journey and strengthened my ethical standards.',
              'initials' => 'SA',
              'name' => 'Sabbir Ahmed, PMP®',
              'role' => 'Senior Project Manager, KONA Software Lab',
            ),
            2 => 
            array (
              'quote' => 'Excellent at communication, documentation and structured execution. He is helpful, empathetic and committed to his team.',
              'initials' => 'FJ',
              'name' => 'Fatema Tuj Jahra',
              'role' => 'Technical Lead',
            ),
            3 => 
            array (
              'quote' => 'A natural leader with superb problem-solving and team-building skills. He brings out the best in each project member.',
              'initials' => 'RI',
              'name' => 'Md. Rakibul Islam',
              'role' => 'Head of Releases',
            ),
            4 => 
            array (
              'quote' => 'He can balance stakeholder expectations with project progress and knows how to protect the key factors for project success.',
              'initials' => 'MZ',
              'name' => 'Mohammad Zobaer Al Zoha',
              'role' => 'ISMS Lead Auditor · CMMI',
            ),
          ),
        ),
        'fields' => 
        array (
          0 => 
          array (
            'name' => 'section_index',
            'label' => 'Section label',
            'type' => 'text',
          ),
          1 => 
          array (
            'name' => 'title',
            'label' => 'Title',
            'type' => 'text',
          ),
          2 => 
          array (
            'name' => 'items',
            'label' => 'Testimonials',
            'type' => 'collection',
            'fields' => 
            array (
              0 => 
              array (
                'name' => 'quote',
                'label' => 'Quote',
                'type' => 'textarea',
                'rows' => 4,
              ),
              1 => 
              array (
                'name' => 'initials',
                'label' => 'Initials',
                'type' => 'text',
              ),
              2 => 
              array (
                'name' => 'name',
                'label' => 'Person name',
                'type' => 'text',
              ),
              3 => 
              array (
                'name' => 'role',
                'label' => 'Role / organization',
                'type' => 'text',
              ),
            ),
          ),
        ),
      ),
      'mentorship' => 
      array (
        'label' => 'Mentorship & Training',
        'description' => 'Main mentorship statement and the four supporting cards.',
        'icon' => 'users',
        'defaults' => 
        array (
          'section_index' => '10 · Mentorship & training',
          'title' => 'Knowledge is an Amanah. Sharing it is part of the work.',
          'description' => 'I have trained and mentored professionals in PMP®, Agile, business analysis, PMO practices, communication, leadership and project tools. Many now contribute at organizations such as bKash, Pathao, KONA and ShareTrip.',
          'cards' => 
          array (
            0 => 
            array (
              'label' => 'Formal training',
              'title' => 'PMP® & project management',
              'description' => 'Exam preparation, practical application and career mentoring.',
            ),
            1 => 
            array (
              'label' => 'Delivery capability',
              'title' => 'Agile, hybrid & PMO',
              'description' => 'Practical governance, ceremonies, reporting, risk and stakeholder work.',
            ),
            2 => 
            array (
              'label' => 'Professional growth',
              'title' => 'Leadership & communication',
              'description' => 'Helping people become clearer, more accountable and more confident.',
            ),
            3 => 
            array (
              'label' => 'Impact',
              'title' => '300+ professionals',
              'description' => 'Across training centers, corporate programs, universities and one-to-one mentoring.',
            ),
          ),
        ),
        'fields' => 
        array (
          0 => 
          array (
            'name' => 'section_index',
            'label' => 'Section label',
            'type' => 'text',
          ),
          1 => 
          array (
            'name' => 'title',
            'label' => 'Title',
            'type' => 'text',
          ),
          2 => 
          array (
            'name' => 'description',
            'label' => 'Introduction',
            'type' => 'textarea',
            'rows' => 5,
          ),
          3 => 
          array (
            'name' => 'cards',
            'label' => 'Mentorship cards',
            'type' => 'collection',
            'fields' => 
            array (
              0 => 
              array (
                'name' => 'label',
                'label' => 'Card label',
                'type' => 'text',
              ),
              1 => 
              array (
                'name' => 'title',
                'label' => 'Card title',
                'type' => 'text',
              ),
              2 => 
              array (
                'name' => 'description',
                'label' => 'Card description',
                'type' => 'textarea',
                'rows' => 3,
              ),
            ),
          ),
        ),
      ),
      'credentials' => 
      array (
        'label' => 'Credentials',
        'description' => 'Certifications, education, learning tags and the animated tools ribbon.',
        'icon' => 'award',
        'defaults' => 
        array (
          'section_index' => '11 · Credentials',
          'title' => 'Formal learning, practical judgment.',
          'description' => 'Certifications matter. They are useful when combined with field experience, business understanding and the humility to keep learning.',
          'certifications' => 
          array (
            0 => 
            array (
              'label' => 'Certification',
              'title' => 'PMP®',
              'description' => 'Project Management Professional, Project Management Institute. Certified since 2016.',
              'logo' => NULL,
              'logo_type' => 'pmp',
            ),
            1 => 
            array (
              'label' => 'Certification',
              'title' => 'CSM®',
              'description' => 'Certified ScrumMaster, Scrum Alliance. Agile facilitation and team delivery practice.',
              'logo' => NULL,
              'logo_type' => 'csm',
            ),
          ),
          'education_label' => 'Education & continued learning',
          'education_title' => 'BBA in Finance · United International University',
          'education_description' => 'Merit scholarship recipient and champion team member of the Citi Financial IT Case Competition. Continued development in product management, Agile, design thinking and digital transformation.',
          'education_logo' => NULL,
          'education_logo_type' => 'uiu',
          'education_tags' => 
          array (
            0 => 
            array (
              'name' => 'Finance',
            ),
            1 => 
            array (
              'name' => 'Product Management',
            ),
            2 => 
            array (
              'name' => 'Agile Meets Design Thinking',
            ),
            3 => 
            array (
              'name' => 'Digital Transformation',
            ),
            4 => 
            array (
              'name' => 'Business Analysis',
            ),
          ),
          'tools' => 
          array (
            0 => 
            array (
              'name' => 'Jira',
              'description' => 'Delivery visibility',
              'logo' => NULL,
              'logo_type' => 'jira',
            ),
            1 => 
            array (
              'name' => 'MS Project',
              'description' => 'Planning & control',
              'logo' => NULL,
              'logo_type' => 'ms-project',
            ),
            2 => 
            array (
              'name' => 'Confluence',
              'description' => 'Knowledge & alignment',
              'logo' => NULL,
              'logo_type' => 'confluence',
            ),
            3 => 
            array (
              'name' => 'Microsoft Excel',
              'description' => 'Analysis & reporting',
              'logo' => NULL,
              'logo_type' => 'excel',
            ),
            4 => 
            array (
              'name' => 'Power BI',
              'description' => 'Reporting & insight',
              'logo' => NULL,
              'logo_type' => 'power-bi',
            ),
            5 => 
            array (
              'name' => 'Agile · Hybrid · Waterfall',
              'description' => 'Context-based methods',
              'logo' => NULL,
              'logo_type' => 'methodology',
            ),
          ),
        ),
        'fields' => 
        array (
          0 => 
          array (
            'name' => 'section_index',
            'label' => 'Section label',
            'type' => 'text',
          ),
          1 => 
          array (
            'name' => 'title',
            'label' => 'Title',
            'type' => 'text',
          ),
          2 => 
          array (
            'name' => 'description',
            'label' => 'Introduction',
            'type' => 'textarea',
            'rows' => 4,
          ),
          3 => 
          array (
            'name' => 'certifications',
            'label' => 'Certifications',
            'type' => 'collection',
            'fields' => 
            array (
              0 => 
              array (
                'name' => 'label',
                'label' => 'Card label',
                'type' => 'text',
              ),
              1 => 
              array (
                'name' => 'title',
                'label' => 'Certification title',
                'type' => 'text',
              ),
              2 => 
              array (
                'name' => 'description',
                'label' => 'Certification description',
                'type' => 'textarea',
                'rows' => 3,
              ),
              3 => 
              array (
                'name' => 'logo',
                'label' => 'Certification logo/image',
                'type' => 'image',
                'help' => 'Upload a PNG, JPG or WebP logo. When empty, the selected fallback mark is used.',
              ),
              4 => 
              array (
                'name' => 'logo_type',
                'label' => 'Certification mark',
                'type' => 'select',
                'options' => 
                array (
                  'pmp' => 'PMP mark',
                  'csm' => 'ScrumMaster mark',
                  'award' => 'Generic award mark',
                ),
              ),
            ),
          ),
          4 => 
          array (
            'name' => 'education_label',
            'label' => 'Education card label',
            'type' => 'text',
          ),
          5 => 
          array (
            'name' => 'education_title',
            'label' => 'Education title',
            'type' => 'text',
          ),
          6 => 
          array (
            'name' => 'education_description',
            'label' => 'Education description',
            'type' => 'textarea',
            'rows' => 4,
          ),
          7 => 
          array (
            'name' => 'education_logo',
            'label' => 'Education logo/image',
            'type' => 'image',
            'help' => 'Upload the institution logo or crest. When empty, the selected fallback mark is used.',
          ),
          8 => 
          array (
            'name' => 'education_logo_type',
            'label' => 'Education mark',
            'type' => 'select',
            'options' => 
            array (
              'uiu' => 'University crest',
              'education' => 'Generic education mark',
            ),
          ),
          9 => 
          array (
            'name' => 'education_tags',
            'label' => 'Education tags',
            'type' => 'collection',
            'fields' => 
            array (
              0 => 
              array (
                'name' => 'name',
                'label' => 'Tag',
                'type' => 'text',
              ),
            ),
          ),
          10 => 
          array (
            'name' => 'tools',
            'label' => 'Tools and methods',
            'type' => 'collection',
            'fields' => 
            array (
              0 => 
              array (
                'name' => 'name',
                'label' => 'Name',
                'type' => 'text',
              ),
              1 => 
              array (
                'name' => 'description',
                'label' => 'Description',
                'type' => 'text',
              ),
              2 => 
              array (
                'name' => 'logo',
                'label' => 'Scrolling logo/image',
                'type' => 'image',
                'help' => 'Upload a transparent PNG, JPG or WebP. When empty, the selected fallback mark is used.',
              ),
              3 => 
              array (
                'name' => 'logo_type',
                'label' => 'Tool mark',
                'type' => 'select',
                'options' => 
                array (
                  'jira' => 'Jira',
                  'ms-project' => 'Microsoft Project',
                  'confluence' => 'Confluence',
                  'excel' => 'Microsoft Excel',
                  'power-bi' => 'Power BI',
                  'methodology' => 'Agile / Hybrid / Waterfall',
                  'generic' => 'Generic tool mark',
                ),
              ),
            ),
          ),
        ),
      ),
      'contact' => 
      array (
        'label' => 'Contact',
        'description' => 'Contact statement, links and footer copy.',
        'icon' => 'mail',
        'defaults' => 
        array (
          'section_index' => '12 · Next conversation',
          'title_prefix' => 'Have a complex project that needs',
          'title_emphasis' => 'clarity?',
          'description' => 'I work with leaders and teams on ERP, project recovery, PMO setup, product delivery, business analysis, technology planning and professional capability. The first conversation can simply be about understanding the real problem.',
          'links' => 
          array (
            0 => 
            array (
              'label' => 'Email',
              'text' => 'aminul@itqanconsulting.com',
              'url' => 'mailto:aminul@itqanconsulting.com',
            ),
            1 => 
            array (
              'label' => 'LinkedIn',
              'text' => 'linkedin.com/in/starpmaminul',
              'url' => 'https://www.linkedin.com/in/starpmaminul',
            ),
            2 => 
            array (
              'label' => 'Consulting',
              'text' => 'itqanconsulting.com',
              'url' => 'https://itqanconsulting.com',
            ),
            3 => 
            array (
              'label' => 'Phone / WhatsApp',
              'text' => '+880 1742 110660',
              'url' => 'tel:+8801742110660',
            ),
          ),
          'footer_identity' => 'Md Aminul Islam, PMP®, CSM® · Dhaka, Bangladesh',
          'footer_quote' => '“And whatever good you put forward for yourselves — you will find it with Allah.” · Al-Baqarah 2:110',
        ),
        'fields' => 
        array (
          0 => 
          array (
            'name' => 'section_index',
            'label' => 'Section label',
            'type' => 'text',
          ),
          1 => 
          array (
            'name' => 'title_prefix',
            'label' => 'Title',
            'type' => 'text',
          ),
          2 => 
          array (
            'name' => 'title_emphasis',
            'label' => 'Emphasized title word',
            'type' => 'text',
          ),
          3 => 
          array (
            'name' => 'description',
            'label' => 'Contact introduction',
            'type' => 'textarea',
            'rows' => 5,
          ),
          4 => 
          array (
            'name' => 'links',
            'label' => 'Contact links',
            'type' => 'collection',
            'fields' => 
            array (
              0 => 
              array (
                'name' => 'label',
                'label' => 'Link label',
                'type' => 'text',
              ),
              1 => 
              array (
                'name' => 'text',
                'label' => 'Displayed text',
                'type' => 'text',
              ),
              2 => 
              array (
                'name' => 'url',
                'label' => 'Link URL',
                'type' => 'text',
                'rules' => 
                array (
                  0 => 'starts_with:http://,https://,mailto:,tel:',
                ),
                'help' => 'Supports https://, mailto: and tel: links.',
              ),
            ),
          ),
          5 => 
          array (
            'name' => 'footer_identity',
            'label' => 'Footer identity',
            'type' => 'text',
          ),
          6 => 
          array (
            'name' => 'footer_quote',
            'label' => 'Footer quote',
            'type' => 'textarea',
            'rows' => 3,
          ),
        ),
      ),
    ),
  ),
  'view' => 
  array (
    'paths' => 
    array (
      0 => '/Applications/XAMPP/xamppfiles/htdocs/laravel/ITQANConsulting/resources/views',
    ),
    'compiled' => '/Applications/XAMPP/xamppfiles/htdocs/laravel/ITQANConsulting/storage/framework/views',
  ),
  'dompdf' => 
  array (
    'show_warnings' => false,
    'public_path' => NULL,
    'convert_entities' => true,
    'options' => 
    array (
      'font_dir' => '/Applications/XAMPP/xamppfiles/htdocs/laravel/ITQANConsulting/storage/fonts',
      'font_cache' => '/Applications/XAMPP/xamppfiles/htdocs/laravel/ITQANConsulting/storage/fonts',
      'temp_dir' => '/var/folders/zz/gnpnh1gj2377hrx3pdzv3llc0000gn/T',
      'chroot' => '/Applications/XAMPP/xamppfiles/htdocs/laravel/ITQANConsulting',
      'allowed_protocols' => 
      array (
        'data://' => 
        array (
          'rules' => 
          array (
          ),
        ),
        'file://' => 
        array (
          'rules' => 
          array (
          ),
        ),
        'http://' => 
        array (
          'rules' => 
          array (
          ),
        ),
        'https://' => 
        array (
          'rules' => 
          array (
          ),
        ),
      ),
      'artifactPathValidation' => NULL,
      'log_output_file' => NULL,
      'enable_font_subsetting' => false,
      'pdf_backend' => 'CPDF',
      'default_media_type' => 'screen',
      'default_paper_size' => 'a4',
      'default_paper_orientation' => 'portrait',
      'default_font' => 'serif',
      'dpi' => 96,
      'enable_php' => false,
      'enable_javascript' => true,
      'enable_remote' => false,
      'allowed_remote_hosts' => NULL,
      'font_height_ratio' => 1.1,
      'enable_html5_parser' => true,
    ),
  ),
  'tinker' => 
  array (
    'commands' => 
    array (
    ),
    'alias' => 
    array (
    ),
    'dont_alias' => 
    array (
      0 => 'App\\Nova',
    ),
    'trust_project' => 'always',
  ),
);
