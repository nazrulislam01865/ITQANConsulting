<?php $__env->startSection('content'); ?>
<?php
  $cleanContactOption = static function ($value): string {
      $value = str_replace(['<br>', '<br/>', '<br />'], ' ', (string) $value);
      return trim((string) preg_replace('/\s+/', ' ', strip_tags($value)));
  };

  $normalizeContactOption = static function ($value) use ($cleanContactOption): string {
      return strtolower($cleanContactOption($value));
  };

  $form = $page['form'] ?? [
      'is_active' => true,
      'label' => 'Start a conversation',
      'title' => 'Send the messy version. We will help organize it.',
      'intro' => 'No pressure. No hard selling. Share what is happening and we will help make the next step clearer.',
      'steps' => [],
      'submit_text' => 'Send the messy version',
      'success_title' => 'Thank you. The first step is clear.',
      'success_text' => 'Your message has been received. ITQAN will contact you soon.',
  ];

  $stepDefaults = [
      ['title' => 'What feels unclear right now?', 'text' => 'Select one or more. It does not need to be perfectly described.'],
      ['title' => 'What kind of support may help?', 'text' => 'Choose what seems closest. ITQAN can help refine the scope later.'],
      ['title' => 'Share the basic details.', 'text' => 'This helps us respond in a useful way.'],
      ['title' => 'Describe the situation in your own words.', 'text' => 'It is okay if the information is incomplete.'],
  ];
  $wizardSteps = array_replace($stepDefaults, $form['steps'] ?? []);

  $problemOptions = $collections['contact_options']['problems'] ?? [
      'Business process',
      'Project delivery',
      'Software or website',
      'ERP or automation',
      'Reporting and data',
      'Team capability',
  ];
  $supportOptions = $collections['contact_options']['needs'] ?? [
      'Consulting first',
      'Plan and manage',
      'Design and build',
      'Review current system',
      'Train the team',
      'Not sure yet',
  ];
  $contactMethods = $collections['contact_options']['methods'] ?? ['WhatsApp', 'Email', 'Phone call', 'Online meeting'];
  $budgetOptions = $collections['contact_options']['budgets'] ?? [
      'Not decided yet',
      'Under BDT 100,000',
      'BDT 100,000 – 300,000',
      'BDT 300,000 – 800,000',
      'Above BDT 800,000',
  ];

  $problemOptions = array_values(array_filter(array_map($cleanContactOption, $problemOptions)));
  $supportOptions = array_values(array_filter(array_map($cleanContactOption, $supportOptions)));
  $contactMethods = array_values(array_filter(array_map($cleanContactOption, $contactMethods)));
  $budgetOptions = array_values(array_filter(array_map($cleanContactOption, $budgetOptions)));

  $serviceSelections = [
      'consulting-business-clarity' => 'Consulting first',
      'project-product-support' => 'Plan and manage',
      'software-web-development' => 'Design and build',
      'erp-automation' => 'Design and build',
      'training-coaching' => 'Train the team',
      'dedicated-team-support' => 'Plan and manage',
  ];

  $requestedService = (string) request()->query('service', '');
  $requestedNeed = (string) request()->query('need', '');
  $preselectedSupport = $serviceSelections[$requestedService] ?? $requestedNeed;

  $oldProblems = old('areas', []);
  $oldProblems = is_array($oldProblems) ? $oldProblems : [$oldProblems];
  $selectedProblemKeys = array_map($normalizeContactOption, $oldProblems);

  $oldSupport = old('support_types', []);
  $oldSupport = is_array($oldSupport) ? $oldSupport : [$oldSupport];
  if ($oldSupport === [] && $preselectedSupport !== '') {
      $oldSupport = [$preselectedSupport];
  }
  $selectedSupportKeys = array_map($normalizeContactOption, $oldSupport);

  if ($preselectedSupport !== '') {
      $preselectedKey = $normalizeContactOption($preselectedSupport);
      $supportKeys = array_map($normalizeContactOption, $supportOptions);
      if ($preselectedKey !== '' && ! in_array($preselectedKey, $supportKeys, true)) {
          $supportOptions[] = $cleanContactOption($preselectedSupport);
      }
  }

  $initialStep = 0;
  if ($errors->hasAny(['message', 'budget', 'captcha', 'g-recaptcha-response'])) {
      $initialStep = 3;
  } elseif ($errors->hasAny(['name', 'company', 'email', 'phone', 'method'])) {
      $initialStep = 2;
  } elseif ($errors->has('support_types')) {
      $initialStep = 1;
  }

  $formActive = (bool) ($form['is_active'] ?? true);
  $cta = $page['cta'] ?? [];
  $ctaActive = (bool) ($cta['is_active'] ?? true);
  $vcard = $cta['vcard'] ?? [];
  $phone = trim((string) ($vcard['phone'] ?? ''));
  $whatsapp = preg_replace('/\D+/', '', (string) ($vcard['whatsapp'] ?? $phone));
  $email = trim((string) ($vcard['email'] ?? ($site['email'] ?? '')));
  $routeName = $cta['button']['route'] ?? null;
  $primaryHref = $cta['button']['url'] ?? (($routeName && Route::has($routeName)) ? route($routeName) : null);
  $primaryExternal = $primaryHref && \Illuminate\Support\Str::startsWith($primaryHref, ['http://', 'https://']);
  $captchaEnabled = app(\App\Services\Frontend\RecaptchaVerifier::class)->isEnabled();
  $captchaSiteKey = trim((string) config('itqan_contact.captcha.site_key'));
?>

<main id="contact" class="page active">
  <?php echo $__env->make('frontend.partials.plain-hero', ['hero' => $page['hero']], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  <?php if($formActive): ?>
  <section class="section contact-experience-section" id="contact-form" aria-labelledby="contactExperienceTitle">
    <div class="container">
      <div class="contact-experience-intro reveal">
        <div class="label"><?php echo e($form['label']); ?></div>
        <h2 id="contactExperienceTitle"><?php echo e($form['title']); ?></h2>
        <p><?php echo e($form['intro']); ?></p>
      </div>

      <div class="contact-experience-grid <?php echo e($ctaActive ? '' : 'single-column'); ?>">
        <form
          class="contact-wizard-card reveal"
          method="post"
          action="<?php echo e(route('contact.submit')); ?>"
          aria-label="Contact form"
          data-contact-wizard
          data-initial-step="<?php echo e($initialStep); ?>"
        >
          <?php echo csrf_field(); ?>

          <div class="contact-wizard-form" <?php if(session('status')): ?> hidden <?php endif; ?>>
            <?php if($errors->any()): ?>
              <div class="contact-wizard-alert error" role="alert">
                <strong>Please correct the highlighted fields.</strong>
                <ul>
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </div>
            <?php endif; ?>

            <div class="contact-wizard-top">
              <div class="contact-wizard-progress" aria-hidden="true"><span></span></div>
              <span class="contact-wizard-count" aria-live="polite">1 of 4</span>
            </div>

            <div class="contact-wizard-step" data-wizard-step="0">
              <h3><?php echo e($wizardSteps[0]['title']); ?></h3>
              <p><?php echo e($wizardSteps[0]['text']); ?></p>
              <div class="contact-choice-grid" role="group" aria-label="Business problems">
                <?php $__currentLoopData = $problemOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php $optionKey = $normalizeContactOption($option); ?>
                  <label class="contact-choice-chip <?php echo e(in_array($optionKey, $selectedProblemKeys, true) ? 'selected' : ''); ?>">
                    <input type="checkbox" name="areas[]" value="<?php echo e($option); ?>" <?php if(in_array($optionKey, $selectedProblemKeys, true)): echo 'checked'; endif; ?>>
                    <span><?php echo e($option); ?></span>
                  </label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>

            <div class="contact-wizard-step" data-wizard-step="1" hidden>
              <h3><?php echo e($wizardSteps[1]['title']); ?></h3>
              <p><?php echo e($wizardSteps[1]['text']); ?></p>
              <div class="contact-choice-grid" role="group" aria-label="Support types">
                <?php $__currentLoopData = $supportOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php $optionKey = $normalizeContactOption($option); ?>
                  <label class="contact-choice-chip <?php echo e(in_array($optionKey, $selectedSupportKeys, true) ? 'selected' : ''); ?>">
                    <input type="checkbox" name="support_types[]" value="<?php echo e($option); ?>" <?php if(in_array($optionKey, $selectedSupportKeys, true)): echo 'checked'; endif; ?>>
                    <span><?php echo e($option); ?></span>
                  </label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>

            <div class="contact-wizard-step" data-wizard-step="2" hidden>
              <h3><?php echo e($wizardSteps[2]['title']); ?></h3>
              <p><?php echo e($wizardSteps[2]['text']); ?></p>
              <div class="contact-wizard-fields">
                <div class="contact-wizard-field">
                  <label for="name">Name</label>
                  <input id="name" name="name" type="text" value="<?php echo e(old('name')); ?>" placeholder="Your name" autocomplete="name" required>
                </div>
                <div class="contact-wizard-field">
                  <label for="company">Company</label>
                  <input id="company" name="company" type="text" value="<?php echo e(old('company')); ?>" placeholder="Company or organization" autocomplete="organization">
                </div>
                <div class="contact-wizard-field">
                  <label for="email">Email</label>
                  <input id="email" name="email" type="email" value="<?php echo e(old('email')); ?>" placeholder="name@company.com" autocomplete="email" required>
                </div>
                <div class="contact-wizard-field">
                  <label for="phone">Phone / WhatsApp</label>
                  <input id="phone" name="phone" type="tel" value="<?php echo e(old('phone')); ?>" placeholder="Your number" autocomplete="tel">
                </div>
                <div class="contact-wizard-field full">
                  <label for="method">Preferred contact</label>
                  <select id="method" name="method">
                    <?php $__currentLoopData = $contactMethods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($method); ?>" <?php if(old('method') === $method): echo 'selected'; endif; ?>><?php echo e($method); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div>
            </div>

            <div class="contact-wizard-step" data-wizard-step="3" hidden>
              <h3><?php echo e($wizardSteps[3]['title']); ?></h3>
              <p><?php echo e($wizardSteps[3]['text']); ?></p>
              <div class="contact-wizard-fields">
                <div class="contact-wizard-field full">
                  <label for="message">What is happening, and what would you like to improve?</label>
                  <textarea id="message" name="message" placeholder="Tell us the messy version..." required><?php echo e(old('message')); ?></textarea>
                </div>
                <div class="contact-wizard-field full">
                  <label for="budget">Tentative budget range</label>
                  <select id="budget" name="budget">
                    <?php $__currentLoopData = $budgetOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $budget): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($budget); ?>" <?php if(old('budget') === $budget): echo 'selected'; endif; ?>><?php echo e($budget); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>

                <?php if($captchaEnabled): ?>
                  <div class="contact-captcha full" data-contact-captcha>
                    <div>
                      <span class="contact-captcha-label">Security verification</span>
                      <p>Please confirm you are not a robot before sending your message.</p>
                    </div>
                    <div class="contact-captcha-widget">
                      <div data-recaptcha-widget data-sitekey="<?php echo e($captchaSiteKey); ?>"></div>
                    </div>
                    <p class="contact-captcha-error" data-captcha-error <?php if(!$errors->has('captcha')): ?> hidden <?php endif; ?>>
                      <?php echo e($errors->first('captcha') ?: 'Please complete the CAPTCHA verification.'); ?>

                    </p>
                  </div>
                <?php endif; ?>
              </div>
            </div>

            <div class="contact-wizard-nav">
              <button class="contact-wizard-button secondary" type="button" data-wizard-back disabled>Back</button>
              <button
                class="contact-wizard-button primary"
                type="button"
                data-wizard-next
                data-continue-label="Continue"
                data-submit-label="Send message"
              >Continue <span aria-hidden="true">→</span></button>
            </div>

            <noscript><p class="contact-wizard-noscript">Please enable JavaScript to use the step-by-step form.</p></noscript>
          </div>

          <div class="contact-wizard-success <?php echo e(session('status') ? 'show' : ''); ?>" <?php if(!session('status')): ?> hidden <?php endif; ?> role="status">
            <div class="contact-wizard-success-icon" aria-hidden="true">✓</div>
            <h3><?php echo e($form['success_title']); ?></h3>
            <p><?php echo e(session('status') ?: $form['success_text']); ?></p>
            <a class="contact-wizard-button secondary" href="<?php echo e(route('contact')); ?>#contact-form">Send another message</a>
          </div>
        </form>

        <?php if($ctaActive): ?>
          <aside class="contact-qr-card reveal" aria-labelledby="contactQrTitle">
            <div>
              <div class="contact-qr-label"><?php echo e($cta['eyebrow'] ?? 'Save the contact'); ?></div>
              <h3 id="contactQrTitle"><?php echo e($cta['title'] ?? 'Keep ITQAN one scan away.'); ?></h3>
              <p><?php echo e($cta['text'] ?? 'Scan the QR code to save the founder’s contact details directly to your phone.'); ?></p>
            </div>

            <div class="contact-qr-frame" aria-label="<?php echo e($cta['qr_alt'] ?? 'ITQAN contact QR code'); ?>">
              <img src="<?php echo e($cta['qr_image_url']); ?>" alt="<?php echo e($cta['qr_alt'] ?? 'ITQAN contact QR code'); ?>" loading="lazy">
              <span class="contact-qr-scan-line" aria-hidden="true"></span>
            </div>

            <?php if(!empty($cta['qr_caption'])): ?>
              <p class="contact-qr-caption"><?php echo e($cta['qr_caption']); ?></p>
            <?php endif; ?>

            <div class="contact-direct-links">
              <?php if($phone !== ''): ?>
                <a href="tel:<?php echo e(preg_replace('/\s+/', '', $phone)); ?>"><span>Call</span><strong><?php echo e($phone); ?></strong></a>
              <?php endif; ?>
              <?php if($whatsapp !== ''): ?>
                <a href="https://wa.me/<?php echo e($whatsapp); ?>" target="_blank" rel="noopener noreferrer"><span>WhatsApp</span><strong>Open chat</strong></a>
              <?php endif; ?>
              <?php if($email !== ''): ?>
                <a href="mailto:<?php echo e($email); ?>"><span>Email</span><strong><?php echo e($email); ?></strong></a>
              <?php endif; ?>
            </div>

            <div class="contact-qr-actions">
              <button class="contact-qr-action" id="saveContactQrCardButton" type="button"><?php echo e($cta['save_button_text'] ?? 'Save Contact'); ?></button>
              <?php if($primaryHref): ?>
                <a class="contact-qr-action primary" href="<?php echo e($primaryHref); ?>" <?php if($primaryExternal): ?> target="_blank" rel="noopener noreferrer" <?php endif; ?>><?php echo e($cta['button']['text'] ?? 'Start a Conversation'); ?></a>
              <?php endif; ?>
            </div>
          </aside>
        <?php endif; ?>
      </div>
    </div>
  </section>
  <?php endif; ?>
</main>
<?php $__env->stopSection(); ?>

<?php if($captchaEnabled): ?>
<?php $__env->startPush('head'); ?>
<script>
  window.itqanRecaptchaReady = () => window.dispatchEvent(new Event('itqan:recaptcha-ready'));
</script>
<script src="https://www.google.com/recaptcha/api.js?onload=itqanRecaptchaReady&render=explicit" async defer></script>
<?php $__env->stopPush(); ?>
<?php endif; ?>

<?php $__env->startPush('scripts'); ?>
<script>
  (() => {
    const saveButton = document.getElementById('saveContactQrCardButton');
    if (!saveButton) return;

    const contact = <?php echo json_encode($vcard, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE, 512) ?>;
    const requestedFileName = <?php echo json_encode($cta['contact_file_name'] ?? 'md-aminul-islam-itqan-consulting.vcf', 15, 512) ?>;

    const escapeVCardValue = (value) => String(value ?? '')
      .replace(/\\/g, '\\\\')
      .replace(/\r?\n/g, '\\n')
      .replace(/;/g, '\\;')
      .replace(/,/g, '\\,');

    const addLine = (lines, key, value) => {
      if (String(value ?? '').trim() !== '') lines.push(`${key}:${escapeVCardValue(value)}`);
    };

    saveButton.addEventListener('click', () => {
      const lines = ['BEGIN:VCARD', 'VERSION:3.0'];
      lines.push(`N:${escapeVCardValue(contact.last_name)};${escapeVCardValue(contact.first_name)};;;${escapeVCardValue(contact.credentials)}`);
      addLine(lines, 'FN', contact.full_name);
      addLine(lines, 'ORG', contact.organization);
      addLine(lines, 'TITLE', contact.job_title);
      addLine(lines, 'TEL;TYPE=CELL,VOICE', contact.phone);
      addLine(lines, 'TEL;TYPE=WHATSAPP', contact.whatsapp);
      addLine(lines, 'EMAIL;TYPE=INTERNET,WORK', contact.email);
      addLine(lines, 'URL', contact.website);
      addLine(lines, 'NOTE', contact.note);
      lines.push('END:VCARD');

      const safeBaseName = String(requestedFileName || 'md-aminul-islam-itqan-consulting.vcf')
        .replace(/[^a-zA-Z0-9._-]+/g, '-')
        .replace(/-+/g, '-')
        .replace(/^-|-$/g, '');
      const fileName = safeBaseName.toLowerCase().endsWith('.vcf') ? safeBaseName : `${safeBaseName}.vcf`;
      const blob = new Blob([lines.join('\r\n')], { type: 'text/vcard;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = fileName;
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    });
  })();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/ITQANConsulting/resources/views/frontend/pages/contact.blade.php ENDPATH**/ ?>